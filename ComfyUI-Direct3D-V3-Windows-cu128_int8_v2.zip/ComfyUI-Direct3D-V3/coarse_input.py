"""Read geometry-only, tightly packed GLBs without materializing a Trimesh."""
import json
import struct
from pathlib import Path

import numpy as np
import torch


def _packed_glb(path):
    with path.open("rb") as stream:
        header = stream.read(20)
        if len(header) != 20:
            return
        magic, version, length, json_size, kind = struct.unpack("<4sIII4s", header)
        if (magic, version, kind) != (b"glTF", 2, b"JSON") or length != path.stat().st_size:
            return
        if json_size > min(length - 28, 16 * 1024**2):
            return
        doc = json.loads(stream.read(json_size))
        bin_size, bin_kind = struct.unpack("<I4s", stream.read(8))
        offset = stream.tell()
    if (bin_kind != b"BIN\0" or offset + bin_size != length
            or doc.get("extensionsUsed") or len(doc["buffers"]) != 1
            or doc["buffers"][0].get("uri") or len(doc["scenes"]) != 1):
        return
    scene_nodes = doc["scenes"][0]["nodes"]
    if len(scene_nodes) != 1:
        return
    node = doc["nodes"][scene_nodes[0]]
    if set(node) - {"mesh", "name", "extras"} or "mesh" not in node:
        return
    primitives = doc["meshes"][node["mesh"]]["primitives"]
    if len(primitives) != 1:
        return
    primitive = primitives[0]
    if (primitive.get("mode", 4) != 4 or "indices" not in primitive
            or "targets" in primitive or "extensions" in primitive):
        return

    def packed(index, kind, component, dtype):
        accessor = doc["accessors"][index]
        if (accessor["type"] != kind or accessor["componentType"] != component
                or accessor.get("normalized") or "sparse" in accessor):
            return
        view = doc["bufferViews"][accessor["bufferView"]]
        if view.get("byteStride") or view["buffer"] != 0:
            return
        start = view.get("byteOffset", 0)
        relative = accessor.get("byteOffset", 0)
        count = accessor["count"]
        columns = 3 if kind == "VEC3" else 1
        size = count * columns * 4
        if (count <= 0 or start < 0 or relative < 0 or (start + relative) % 4
                or relative + size > view["byteLength"]
                or start + relative + size > bin_size):
            return
        return np.memmap(path, mode="c", offset=offset + start + relative,
                         dtype=dtype, shape=(count, columns))

    positions = packed(primitive["attributes"]["POSITION"], "VEC3", 5126, "<f4")
    indices = packed(primitive["indices"], "SCALAR", 5125, "<u4")
    if positions is None or indices is None or indices.size % 3:
        return
    if indices.max() >= len(positions) or len(positions) > np.iinfo(np.int32).max:
        raise ValueError("Coarse GLB has invalid triangle indices.")
    for start in range(0, len(positions), 1_000_000):
        if not np.isfinite(positions[start:start + 1_000_000]).all():
            raise ValueError("Coarse GLB has non-finite vertices.")
    return positions, indices.view("<i4").reshape(-1, 3)


def upload_coarse(source, device):
    from direct3d.utils.mesh import load_coarse

    path = Path(source)
    packed = _packed_glb(path) if path.suffix.lower() == ".glb" else None
    if packed is not None:
        print("INFO Uploading packed GLB coordinates and indices directly", flush=True)
        return tuple(torch.from_numpy(array).to(device, copy=True) for array in packed)
    mesh = load_coarse(path)
    vertices = torch.as_tensor(mesh.vertices, dtype=torch.float32, device=device)
    faces = torch.as_tensor(mesh.faces, dtype=torch.int32, device=device)
    return vertices, faces
