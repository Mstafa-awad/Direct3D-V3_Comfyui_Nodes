"""ComfyUI nodes; no Direct3D / model imports in this file."""
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXTENSIONS = {".obj", ".glb", ".ply"}


class AnyMesh(str):
    """Allow connected meshes from differing ComfyUI 3D packs."""
    def __ne__(self, other):
        return False

    def __eq__(self, other):
        return True


ANY_MESH = AnyMesh("*")


def _folder_paths():
    import folder_paths
    return folder_paths


def _input_mesh_files():
    base = Path(_folder_paths().get_input_directory())
    names = []
    if base.is_dir():
        for dirpath, subdirs, files in os.walk(base):
            subdirs[:] = [d for d in subdirs if not d.startswith(".")]
            for file in files:
                if Path(file).suffix.lower() in EXTENSIONS:
                    names.append(str((Path(dirpath) / file).relative_to(base)).replace("\\", "/"))
                if len(names) > 2000:
                    break
            if len(names) > 2000:
                break
    return sorted(names) or ["[Place an OBJ/GLB/PLY in ComfyUI/input first]"]


def _safe_file_path(path):
    if not isinstance(path, (str, os.PathLike)):
        raise ValueError("Expected a path to an OBJ/GLB/PLY file")
    value = str(path).strip().strip('"')
    candidate = Path(value).expanduser()
    if not candidate.is_absolute():
        candidate = Path(_folder_paths().get_input_directory()) / candidate
    candidate = candidate.resolve()
    if candidate.suffix.lower() not in EXTENSIONS:
        raise ValueError(f"Unsupported coarse mesh extension: {candidate.suffix}. Use OBJ, GLB or PLY.")
    if not candidate.is_file():
        raise FileNotFoundError(f"Cannot find coarse mesh: {candidate}")
    return candidate


def _numpy(t):
    if hasattr(t, "detach"):
        t = t.detach()
    if hasattr(t, "cpu"):
        t = t.cpu()
    if hasattr(t, "numpy"):
        return t.numpy()
    import numpy as np
    return np.asarray(t)


def _convert_mesh(source, path):
    """Serialize a connected Trimesh, Scene, basic vertex/face object or mesh path."""
    if isinstance(source, (str, os.PathLike)):
        return _safe_file_path(source)
    import trimesh
    v3 = getattr(source, "vertices", None)
    if v3 is not None and getattr(v3, "ndim", 0) == 3:
        # ComfyUI native MESH (official TRELLIS.2 / Pixal3D / Hunyuan3D nodes): batched (B, N, 3), glTF Y-up.
        # Only the first mesh of a batch is refined.
        nv = int(source.vertex_counts[0]) if getattr(source, "vertex_counts", None) is not None else v3.shape[1]
        nf = int(source.face_counts[0]) if getattr(source, "face_counts", None) is not None else source.faces.shape[1]
        if v3.shape[0] > 1:
            print(f"[Direct3D-V3] Input MESH batch has {v3.shape[0]} meshes; refining the first one.")
        source = trimesh.Trimesh(vertices=_numpy(v3[0, :nv]).astype("float32"),
                                 faces=_numpy(source.faces[0, :nf]).astype("int64"), process=False)
        if len(source.vertices) == 0 or len(source.faces) == 0:
            raise ValueError("Input mesh is empty")
    if isinstance(source, trimesh.Scene):
        source = source.dump(concatenate=True)
    if isinstance(source, trimesh.Trimesh):
        source.export(str(path))
        return path
    if isinstance(source, dict):
        if "mesh" in source:
            return _convert_mesh(source["mesh"], path)
        v = source.get("vertices", source.get("verts"))
        f = source.get("faces", source.get("triangles"))
    elif isinstance(source, (tuple, list)) and len(source) == 2:
        v, f = source
    else:
        v = getattr(source, "vertices", getattr(source, "verts", None))
        f = getattr(source, "faces", getattr(source, "triangles", None))
    if v is None or f is None:
        raise TypeError(
            f"Unsupported mesh object ({type(source).__name__}); supply Trimesh, Scene, "
            "vertices/faces, or connect the 'Direct3D Mesh File' node instead."
        )
    mesh = trimesh.Trimesh(vertices=_numpy(v), faces=_numpy(f), process=False)
    if len(mesh.vertices) == 0 or len(mesh.faces) == 0:
        raise ValueError("Input mesh is empty")
    mesh.export(str(path))
    return path


def _write_image(image, path, mask=None):
    import numpy as np
    from PIL import Image
    import torch
    import torch.nn.functional as F
    if image.ndim != 4 or image.shape[0] < 1:
        raise ValueError("IMAGE expected in ComfyUI [B,H,W,C] format")
    arr = (_numpy(image[0]).clip(0, 1) * 255).round().astype("uint8")
    if arr.shape[-1] < 3:
        arr = np.repeat(arr[..., :1], 3, axis=-1)
    if arr.shape[-1] > 4:
        arr = arr[..., :4]
    if mask is not None:
        # Comfy masks are normally 0=background, 1=foreground.
        m = mask[0] if mask.ndim == 3 else mask
        m = m.detach().float().cpu().unsqueeze(0).unsqueeze(0)
        if m.shape[-2:] != arr.shape[:2]:
            m = F.interpolate(m, size=arr.shape[:2], mode="bilinear", align_corners=False)
        alpha = (m[0, 0].clamp(0, 1).numpy() * 255).round().astype("uint8")
        arr = np.concatenate([arr[..., :3], alpha[..., None]], axis=-1)
    Image.fromarray(arr).save(str(path))
    return mask is not None or arr.shape[2] == 4


def _python():
    """The node's own .runtime venv if present, otherwise ComfyUI's Python (saves ~7 GB when it has the same
    torch build and the worker's packages, e.g. ComfyUI-Easy-Install's python_embeded with torch 2.8.0+cu128)."""
    p = ROOT / ".runtime" / "Scripts" / "python.exe"
    if p.is_file():
        return p
    try:
        import torch
        import safetensors  # noqa: F401
        import transformers  # noqa: F401
        if torch.cuda.is_available():
            print(f"[Direct3D-V3] No .runtime venv; using ComfyUI's Python {sys.executable} (torch {torch.__version__})")
            return Path(sys.executable)
    except Exception as error:
        print(f"[Direct3D-V3] ComfyUI's Python cannot run the worker: {error}")
    raise RuntimeError(
        "Direct3D-V3 runtime is not installed and ComfyUI's Python lacks CUDA torch, safetensors or transformers. "
        "Restore the .runtime folder or run setup.cmd."
    )


def _clean_prefix(prefix):
    name = re.sub(r"[^A-Za-z0-9_.-]", "_", str(prefix).strip())[:72]
    name = name.strip("._-")
    return name or "Direct3D"


def _unload_comfy():
    try:
        import comfy.model_management as mm
        mm.unload_all_models()
        if hasattr(mm, "soft_empty_cache"):
            mm.soft_empty_cache()
    except Exception as exc:
        print(f"[Direct3D-V3] Could not fully unload Comfy models: {exc}")
    try:
        import torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except Exception:
        pass


# Quality / speed options added by @MostAadTech. All optional; the defaults reproduce the earlier behaviour.
_EXTRA_OPTIONS = ("start_resolution", "guidance_mode", "apg_eta", "apg_norm_threshold", "fdg_high_scale",
                  "cfg_skip_last_steps", "surface_extraction")


def _stage_list(resolution, stage_mode, start_resolution="auto"):
    target = int(resolution)
    start = str(start_resolution or "auto")
    if start == "auto":
        return [target] if stage_mode == "single_stage" else [r for r in (512, 1024, 1536) if r <= target]
    start = min(int(start), target)
    return [r for r in (512, 1024, 1536) if start <= r <= target]


def _pick_options(values):
    return {k: values.pop(k) for k in _EXTRA_OPTIONS if k in values}


def _launch(image, coarse_mesh, *, resolution, steps, guidance, max_tokens, token_fit,
            seed, model, dtype, offline, use_alpha, output_prefix, file_format, stage_mode, mask=None,
            attention_backend="efficient", accel_mode="lossless", views=None, multiview=None, options=None,
            save_file=True, want_mesh=False):
    import folder_paths
    output_dir = Path(folder_paths.get_output_directory()) / "Direct3D-V3"
    if save_file:
        output_dir.mkdir(parents=True, exist_ok=True)
    # Unique prefix even if user queues the same node repeatedly.
    import uuid
    output_path = output_dir / f"{_clean_prefix(output_prefix)}_{uuid.uuid4().hex[:8]}.{file_format}"
    temp_base = Path(folder_paths.get_temp_directory())
    temp_base.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="direct3d_", dir=str(temp_base)) as tdir:
        temp = Path(tdir)
        image_path = temp / "reference.png"
        existing_alpha = _write_image(image, image_path, mask=mask)
        mesh_path = _convert_mesh(coarse_mesh, temp / "coarse.glb")
        cfg = {
            "image": str(image_path), "coarse_mesh": str(mesh_path), "output": str(output_path) if save_file else "",
            "resolution": int(resolution), "steps": int(steps), "guidance": float(guidance),
            "max_tokens": int(max_tokens), "token_fit": token_fit,
            "seed": int(seed), "model": model.strip() or "wushuang98/Direct3D-V3",
            "dtype": dtype, "offline": bool(offline), "use_alpha": bool(use_alpha and existing_alpha),
            "stage_mode": stage_mode, "attention_backend": attention_backend, "accel_mode": accel_mode,
        }
        cfg.update(options or {})
        raw_path = temp / "result"
        if want_mesh:
            cfg["raw_output"] = str(raw_path)
        stages = _stage_list(resolution, stage_mode, cfg.get("start_resolution", "auto"))
        if views:
            # Multiview node only (Made by @MostAadTech): one RGBA file per extra view.
            specs = []
            for name, view_image, view_mask, azimuth, elevation, weight in views:
                view_path = temp / f"view_{name}.png"
                has_alpha = _write_image(view_image, view_path, mask=view_mask)
                specs.append({"name": name, "image": str(view_path), "azimuth": azimuth, "elevation": elevation,
                              "weight": float(weight), "alpha": bool(has_alpha)})
            cfg["views"] = specs
            cfg.update(multiview or {})
        config_path = temp / "run.json"
        config_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
        _unload_comfy()
        env = os.environ.copy()
        env.update({"PYTHONUTF8": "1", "PYTHONUNBUFFERED": "1", "HF_HUB_DISABLE_SYMLINKS_WARNING": "1"})
        # ComfyUI can select cudaMallocAsync in its own process. Use the
        # measured native allocator in this separate worker.
        env["PYTORCH_CUDA_ALLOC_CONF"] = "backend:native"
        env["PYTORCH_ALLOC_CONF"] = "backend:native"
        worker = ROOT / "worker.py"
        command = [str(_python()), "-u", str(worker), "--config", str(config_path)]
        history = []
        total = len(stages) * steps
        try:
            from comfy.utils import ProgressBar
            bar = ProgressBar(total)
        except Exception:
            bar = None
        completed = 0
        print(f"[Direct3D-V3] Starting {resolution} on low-VRAM worker. Output: {output_path}")
        # stderr merged; stdout line-buffered; no shell or arbitrary commands.
        proc = subprocess.Popen(command, cwd=str(ROOT), env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace",
                                bufsize=1, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        try:
            for line in proc.stdout:
                s = line.rstrip()
                history.append(s)
                if len(history) > 350:
                    history.pop(0)
                console_encoding = getattr(sys.stdout, "encoding", None) or "utf-8"
                printable = s.encode(console_encoding, errors="backslashreplace").decode(console_encoding)
                print("[Direct3D-V3] " + printable)
                if s.startswith("PROGRESS ") and bar is not None:
                    parts = s.split()
                    if len(parts) >= 4:
                        # Upstream can issue step zero; only count monotonically increasing work.
                        done = min(int(parts[2]), steps)
                        stage_id = int(parts[1])
                        idx = stages.index(stage_id) if stage_id in stages else 0
                        wanted = idx * steps + done
                        if wanted > completed:
                            bar.update(wanted - completed)
                            completed = wanted
            code = proc.wait()
        finally:
            if proc.poll() is None:
                proc.kill()
                proc.wait()
            proc.stdout.close()
        missing = (save_file and not output_path.is_file()) or (want_mesh and not Path(str(raw_path) + ".v.npy").is_file())
        if code != 0 or missing:
            if output_path.exists():
                output_path.unlink()
            tail = "\n".join(history[-30:])
            raise RuntimeError(f"Direct3D-V3 worker failed (exit code {code}).\n{tail}")
        if not want_mesh:
            info = f"Exported {output_path.name} at stage {resolution}; see Comfy console for logs."
            return (str(output_path), str(output_path), info)
        import numpy as np
        vertices = np.load(str(raw_path) + ".v.npy")
        faces = np.load(str(raw_path) + ".f.npy")
        info = (f"{len(vertices)} vertices, {len(faces)} triangles at {resolution}"
                + (f"; saved {output_path}" if save_file else ""))
        return (vertices, faces), (str(output_path) if save_file else ""), info


class Direct3DMeshFile:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"mesh_file": (_input_mesh_files(),)}}

    RETURN_TYPES = ("MESH_PATH",)
    RETURN_NAMES = ("coarse_mesh_path",)
    FUNCTION = "get_file"
    CATEGORY = "Direct3D-V3"

    def get_file(self, mesh_file):
        return (str(_safe_file_path(mesh_file)),)


class Direct3DMeshPath:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"absolute_or_input_relative_path": ("STRING", {"default": "", "multiline": False})}}

    RETURN_TYPES = ("MESH_PATH",)
    RETURN_NAMES = ("coarse_mesh_path",)
    FUNCTION = "get_file"
    CATEGORY = "Direct3D-V3"

    def get_file(self, absolute_or_input_relative_path):
        return (str(_safe_file_path(absolute_or_input_relative_path)),)


class _BaseRefine:
    RETURN_TYPES = ("MESH_PATH", "STRING", "STRING")
    RETURN_NAMES = ("mesh_path", "mesh_path_text", "info")
    FUNCTION = "refine"
    CATEGORY = "Direct3D-V3"
    OUTPUT_NODE = True

    @staticmethod
    def _optional_settings():
        return {
            "foreground_mask": ("MASK",),
            "attention_backend": (["efficient", "cudnn_fp16"], {
                "default": "efficient",
                "tooltip": "Used only when accel_mode is off. Experimental cuDNN for large FP16 attention calls.",
            }),
            "accel_mode": (["lossless", "fast", "fastest", "off"], {
                "default": "lossless",
                "tooltip": "Triton kernels for FP16 dtype. lossless: same quality as FP16 (rounding-level differences), "
                           "~1.6x faster sampling. fast: adds INT8 attention scores and SmoothQuant INT8 for the "
                           "least sensitive layers, ~2.1x, small deviation. fastest: also INT8 MLP, ~2.3x, deviation "
                           "near BF16 level. off: original path.",
            }),
            "start_resolution": (["auto", "512", "1024", "1536"], {
                "default": "auto",
                "tooltip": "First stage of the run; stages then go up to 'resolution' (e.g. 1024 -> 1536 skips 512). "
                           "auto: cascade starts at 512, single_stage runs only 'resolution'. A start above the "
                           "target runs the target alone.",
            }),
            "guidance_mode": (["cfg", "apg", "fdg"], {
                "default": "cfg",
                "tooltip": "cfg: original classifier-free guidance. apg: adaptive projected guidance, less "
                           "over-saturation of thin relief. fdg: frequency-decoupled guidance, 'guidance' for the "
                           "overall shape and fdg_high_scale for fine detail. Same speed for all three.",
            }),
            "apg_eta": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 1.0, "step": 0.05,
                                  "tooltip": "apg only: weight of the saturating (parallel) guidance part; 1 = cfg."}),
            "apg_norm_threshold": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 100.0, "step": 0.5,
                                             "tooltip": "apg only: cap on the per-patch guidance size; 0 = off."}),
            "fdg_high_scale": ("FLOAT", {"default": 6.0, "min": 0.0, "max": 20.0, "step": 0.25,
                                         "tooltip": "fdg only: guidance for fine detail ('guidance' is used for "
                                                    "the low-frequency shape)."}),
            "cfg_skip_last_steps": ("INT", {"default": 0, "min": 0, "max": 5,
                                            "tooltip": "Run the last N steps without guidance (no unconditional "
                                                       "pass). Each skipped step saves about 6% at 8 steps."}),
            "surface_extraction": (["marching_cubes", "dual_contouring"], {
                "default": "marching_cubes",
                "tooltip": "Final mesh extraction. dual_contouring (sparse, GPU, made by @MostAadTech) keeps sharp "
                           "edges and corners instead of rounding them. No decimation either way.",
            }),
        }

    @staticmethod
    def _settings():
        return {
            "image": ("IMAGE",),
            "resolution": ([512, 1024, 1536], {"default": 1536}),
            "steps": ("INT", {"default": 8, "min": 1, "max": 100}),
            "guidance": ("FLOAT", {"default": 4.0, "min": 0.0, "max": 20.0, "step": 0.25}),
            "max_tokens": ("INT", {"default": 50000, "min": 1000, "max": 170000, "step": 1000}),
            "token_fit": (["shrink_to_fit", "preserve_scale"], {"default": "preserve_scale",
                            "tooltip": "Preserve scale refuses a mesh above the cap. Shrink to fit can reduce geometric detail."}),
            "seed": ("INT", {"default": 2026, "min": 0, "max": 2**63 - 1}),
            "model": ("STRING", {"default": "wushuang98/Direct3D-V3"}),
            "dtype": (["fp16", "bf16"], {"default": "fp16"}),
            "offline": ("BOOLEAN", {"default": True}),
            "use_alpha": ("BOOLEAN", {"default": True}),
            "output_prefix": ("STRING", {"default": "Direct3D_refined"}),
            "file_format": (["glb", "obj", "ply"], {"default": "glb"}),
            "stage_mode": (["cascade", "single_stage"], {"default": "single_stage"}),
        }


class Direct3DRefineFile(_BaseRefine):
    """Takes input image + mesh file (from File, Path or other mesh file nodes)."""
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"coarse_mesh_path": ("MESH_PATH",), **cls._settings()},
                "optional": cls._optional_settings()}

    def refine(self, coarse_mesh_path, image, resolution, steps, guidance, max_tokens,
               token_fit, seed, model, dtype, offline, use_alpha, output_prefix,
               file_format, stage_mode, foreground_mask=None, attention_backend="efficient",
               accel_mode="lossless", **options):
        return _launch(image, _safe_file_path(coarse_mesh_path), resolution=resolution,
                       steps=steps, guidance=guidance, max_tokens=max_tokens,
                       token_fit=token_fit, seed=seed, model=model, dtype=dtype,
                       offline=offline, use_alpha=use_alpha, output_prefix=output_prefix,
                       file_format=file_format, stage_mode=stage_mode, mask=foreground_mask,
                       attention_backend=attention_backend, accel_mode=accel_mode,
                       options=_pick_options(options))


class Direct3DRefineConnected(_BaseRefine):
    """Accepts a connected Trimesh/Scene/vertices+faces object from another pack."""
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"coarse_mesh": (ANY_MESH,), **cls._settings()},
                "optional": cls._optional_settings()}

    def refine(self, coarse_mesh, image, resolution, steps, guidance, max_tokens,
               token_fit, seed, model, dtype, offline, use_alpha, output_prefix,
               file_format, stage_mode, foreground_mask=None, attention_backend="efficient",
               accel_mode="lossless", **options):
        return _launch(image, coarse_mesh, resolution=resolution,
                       steps=steps, guidance=guidance, max_tokens=max_tokens,
                       token_fit=token_fit, seed=seed, model=model, dtype=dtype,
                       offline=offline, use_alpha=use_alpha, output_prefix=output_prefix,
                       file_format=file_format, stage_mode=stage_mode, mask=foreground_mask,
                       attention_backend=attention_backend, accel_mode=accel_mode,
                       options=_pick_options(options))


_VIEW_SLOTS = (
    ("back", 180, 0, "Photo of the back (camera behind the model)."),
    ("left", 90, 0, "Model's left side (camera on +x, the right side of the front image)."),
    ("right", 270, 0, "Model's right side (camera on -x, the left side of the front image)."),
    ("top", 0, 90, "Seen from above; the front of the model at the image's bottom edge."),
    ("bottom", 0, -90, "Seen from below; the front of the model at the image's top edge."),
)


class Direct3DRefineMultiview(_BaseRefine):
    """Front image plus optional back / left / right / top / bottom views (training-free). Made by @MostAadTech."""
    DESCRIPTION = ("Multiview refinement made by @MostAadTech: each extra view runs the model in a turned patch frame "
                   "and the predictions are blended per patch. Each connected view adds about one extra sampling pass.")

    @classmethod
    def INPUT_TYPES(cls):
        optional = cls._optional_settings()
        for name, _, _, tip in _VIEW_SLOTS:
            optional[f"{name}_image"] = ("IMAGE", {"tooltip": tip})
            optional[f"{name}_mask"] = ("MASK", {"tooltip": f"Foreground mask for the {name} view (white = object)."})
            optional[f"{name}_weight"] = ("FLOAT", {"default": 1.0, "min": 0.0, "max": 10.0, "step": 0.05,
                                                     "tooltip": f"Relative weight of the {name} view."})
        optional["multiview_mode"] = (["facing", "visible", "blend", "average"], {
            "default": "facing",
            "tooltip": "facing: each surface patch follows the view that sees it most head-on (uses the coarse mesh "
                       "normals). visible: the front keeps every patch it sees; hidden patches go to the other views. "
                       "blend: smooth direction-based mix. average: same mix everywhere."})
        optional["front_weight"] = ("FLOAT", {"default": 1.0, "min": 0.01, "max": 10.0, "step": 0.05})
        optional["boundary_feather"] = ("INT", {"default": 1, "min": 0, "max": 4,
                                                "tooltip": "Soften seams between views over this many patches."})
        optional["multiview_speed"] = (["quality", "fast"], {
            "default": "quality",
            "tooltip": "quality: every view runs its own guided passes. fast: views share the front's unconditional "
                       "pass (about 45% less time per extra view, small deviation)."})
        return {"required": {"coarse_mesh": (ANY_MESH,), **cls._settings()}, "optional": optional}

    def refine(self, coarse_mesh, image, resolution, steps, guidance, max_tokens,
               token_fit, seed, model, dtype, offline, use_alpha, output_prefix,
               file_format, stage_mode, foreground_mask=None, attention_backend="efficient",
               accel_mode="lossless", multiview_mode="facing", front_weight=1.0, boundary_feather=1,
               multiview_speed="quality", **views_in):
        options = _pick_options(views_in)
        views = []
        for name, azimuth, elevation, _ in _VIEW_SLOTS:
            view_image = views_in.get(f"{name}_image")
            if view_image is not None:
                views.append((name, view_image, views_in.get(f"{name}_mask"), azimuth, elevation,
                              views_in.get(f"{name}_weight", 1.0)))
        if not views:
            raise ValueError("Connect at least one extra view (back, left, right, top or bottom), "
                             "or use the single-view Refine node.")
        return _launch(image, coarse_mesh, resolution=resolution,
                       steps=steps, guidance=guidance, max_tokens=max_tokens,
                       token_fit=token_fit, seed=seed, model=model, dtype=dtype,
                       offline=offline, use_alpha=use_alpha, output_prefix=output_prefix,
                       file_format=file_format, stage_mode=stage_mode, mask=foreground_mask,
                       attention_backend=attention_backend, accel_mode=accel_mode, views=views,
                       options=options,
                       multiview={"multiview_mode": multiview_mode, "front_weight": float(front_weight),
                                  "multiview_feather": int(boundary_feather),
                                  "multiview_share_uncond": multiview_speed == "fast"})


# ---------------------------------------------------------------------------------------------------------------
# Simple nodes (Made by @MostAadTech): MESH in (official TRELLIS.2 / Pixal3D / Hunyuan3D nodes), MESH out (connect
# "Save 3D Model" or any MESH node), optional direct file export. Expert settings use tested defaults.
# ---------------------------------------------------------------------------------------------------------------
def _to_comfy_mesh(vertices, faces):
    import torch
    from comfy_api.latest import Types
    return Types.MESH(vertices=torch.from_numpy(vertices).float()[None],
                      faces=torch.from_numpy(faces.astype("int32"))[None])


class Direct3DV3Refine:
    """Refine a coarse mesh into a detailed mesh with Direct3D-V3 (INT8, low VRAM). Made by @MostAadTech."""
    DESCRIPTION = ("Direct3D-V3 refiner made by @MostAadTech. Connect the MESH from TRELLIS.2 / Pixal3D / Hunyuan3D and "
                   "the same image. Output MESH goes to 'Save 3D Model' or any mesh node; or tick save_file.")
    RETURN_TYPES = ("MESH", "STRING")
    RETURN_NAMES = ("mesh", "file_path")
    FUNCTION = "refine"
    CATEGORY = "Direct3D-V3"
    OUTPUT_NODE = True

    @classmethod
    def _common(cls):
        return {
            "mesh": ("MESH", {"tooltip": "Coarse mesh, e.g. the MESH output of the TRELLIS.2 or Pixal3D nodes."}),
            "image": ("IMAGE", {"tooltip": "The same image used to make the coarse mesh (front view)."}),
            "resolution": ([512, 1024, 1536], {"default": 1536,
                           "tooltip": "Final detail level. 1536 = most detail, 1024 = good balance, 512 = fast preview."}),
            "start_from": (["same as resolution", "512", "1024"], {"default": "same as resolution",
                           "tooltip": "Run lower stages first (e.g. 1024 then 1536). 'same as resolution' runs one stage."}),
            "steps": ("INT", {"default": 8, "min": 1, "max": 50}),
            "guidance": ("FLOAT", {"default": 4.0, "min": 1.0, "max": 10.0, "step": 0.25,
                         "tooltip": "How strongly to follow the image. 4 is the model default."}),
            "seed": ("INT", {"default": 0, "min": 0, "max": 2**63 - 1}),
            "speed": (["lossless", "fast", "fastest", "off"], {"default": "lossless",
                      "tooltip": "lossless: same quality, about 1.6x faster. fast: about 2x, tiny change. "
                                 "fastest: about 2.2x. off: original code (slowest)."}),
            "max_tokens": ("INT", {"default": 150000, "min": 10000, "max": 300000, "step": 5000,
                           "tooltip": "Upper limit of 8x8x8 surface patches. About 150k fits an 8 GB GPU at 1536."}),
            "fit_large_meshes": ("BOOLEAN", {"default": True,
                                 "tooltip": "On: big meshes are scaled down to fit max_tokens. Off: stop with an error."}),
            "sharp_edges": ("BOOLEAN", {"default": False,
                            "tooltip": "Dual contouring: keeps hard edges and corners (buildings, props). "
                                       "Off: marching cubes (smooth, organic)."}),
            "save_file": ("BOOLEAN", {"default": False,
                          "tooltip": "Also write the mesh to ComfyUI/output/Direct3D-V3 in the format below."}),
            "file_format": (["glb", "obj", "ply", "stl"], {"default": "glb"}),
            "filename_prefix": ("STRING", {"default": "Direct3D-V3"}),
        }

    @classmethod
    def _advanced(cls):
        return {
            "mask": ("MASK", {"tooltip": "Optional foreground mask (white = object). Not needed if the image has alpha."}),
            "guidance_method": (["cfg", "apg", "fdg"], {"default": "cfg",
                                "tooltip": "cfg: standard. apg: slightly less over-saturated guidance. "
                                           "fdg: extra guidance on fine detail."}),
            "skip_guidance_last_steps": ("INT", {"default": 0, "min": 0, "max": 5,
                                         "tooltip": "Last N steps without guidance: about 6% faster each at 8 steps."}),
        }

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": cls._common(), "optional": cls._advanced()}

    @staticmethod
    def _run(mesh, image, resolution, start_from, steps, guidance, seed, speed, max_tokens, fit_large_meshes,
             sharp_edges, save_file, file_format, filename_prefix, mask=None, guidance_method="cfg",
             skip_guidance_last_steps=0, views=None, multiview=None):
        start = str(resolution) if start_from == "same as resolution" else start_from
        options = {"start_resolution": start, "guidance_mode": guidance_method,
                   "cfg_skip_last_steps": int(skip_guidance_last_steps),
                   "surface_extraction": "dual_contouring" if sharp_edges else "marching_cubes"}
        (v, f), path, info = _launch(
            image, mesh, resolution=int(resolution), steps=steps, guidance=guidance, max_tokens=max_tokens,
            token_fit="shrink_to_fit" if fit_large_meshes else "preserve_scale", seed=seed,
            model="wushuang98/Direct3D-V3", dtype="fp16", offline=True, use_alpha=True,
            output_prefix=filename_prefix, file_format=file_format, stage_mode="cascade", mask=mask,
            attention_backend="efficient", accel_mode=speed, views=views, multiview=multiview, options=options,
            save_file=bool(save_file), want_mesh=True)
        print(f"[Direct3D-V3] {info}")
        return (_to_comfy_mesh(v, f), path)

    def refine(self, **kwargs):
        return self._run(**kwargs)


class Direct3DV3RefineMultiview(Direct3DV3Refine):
    """Front image plus optional back / left / right / top / bottom views. Made by @MostAadTech."""
    DESCRIPTION = ("Multiview Direct3D-V3 refiner made by @MostAadTech: add photos of other sides for better back and "
                   "side detail. Each extra view adds about one more sampling pass.")

    @classmethod
    def INPUT_TYPES(cls):
        optional = {}
        for name, _, _, tip in _VIEW_SLOTS:
            optional[f"{name}_image"] = ("IMAGE", {"tooltip": tip})
            optional[f"{name}_mask"] = ("MASK", {"tooltip": f"Foreground mask for the {name} view (white = object)."})
        optional["multiview_speed"] = (["quality", "fast"], {
            "default": "quality",
            "tooltip": "fast: views share one guidance pass (about 45% less time per extra view, tiny change)."})
        optional.update(cls._advanced())
        return {"required": cls._common(), "optional": optional}

    def refine(self, multiview_speed="quality", **kwargs):
        views = []
        for name, azimuth, elevation, _ in _VIEW_SLOTS:
            view_image = kwargs.pop(f"{name}_image", None)
            view_mask = kwargs.pop(f"{name}_mask", None)
            if view_image is not None:
                views.append((name, view_image, view_mask, azimuth, elevation, 1.0))
        if not views:
            raise ValueError("Connect at least one extra view (back, left, right, top or bottom), "
                             "or use the single-view Direct3D-V3 Refine node.")
        return self._run(views=views, multiview={"multiview_mode": "facing", "front_weight": 1.0,
                                                 "multiview_feather": 1,
                                                 "multiview_share_uncond": multiview_speed == "fast"}, **kwargs)


for _legacy in (Direct3DMeshFile, Direct3DMeshPath, Direct3DRefineFile, Direct3DRefineConnected,
                Direct3DRefineMultiview):
    _legacy.CATEGORY = "Direct3D-V3/legacy"


NODE_CLASS_MAPPINGS = {
    "Direct3DV3Refine": Direct3DV3Refine,
    "Direct3DV3RefineMultiview": Direct3DV3RefineMultiview,
    # Legacy nodes kept so older workflows still load.
    "Direct3DMeshFileClean": Direct3DMeshFile,
    "Direct3DMeshPathClean": Direct3DMeshPath,
    "Direct3DRefineFileClean": Direct3DRefineFile,
    "Direct3DRefineConnectedClean": Direct3DRefineConnected,
    "Direct3DRefineMultiviewClean": Direct3DRefineMultiview,
}
NODE_DISPLAY_NAME_MAPPINGS = {
    "Direct3DV3Refine": "Direct3D-V3 Refine (Made by @MostAadTech)",
    "Direct3DV3RefineMultiview": "Direct3D-V3 Refine Multiview (Made by @MostAadTech)",
    "Direct3DMeshFileClean": "Direct3D-V3 (legacy) Choose Coarse Mesh File",
    "Direct3DMeshPathClean": "Direct3D-V3 (legacy) Mesh File Path",
    "Direct3DRefineFileClean": "Direct3D-V3 (legacy) Refine Mesh File",
    "Direct3DRefineConnectedClean": "Direct3D-V3 (legacy) Refine Connected Mesh",
    "Direct3DRefineMultiviewClean": "Direct3D-V3 (legacy) Refine Multiview",
}
