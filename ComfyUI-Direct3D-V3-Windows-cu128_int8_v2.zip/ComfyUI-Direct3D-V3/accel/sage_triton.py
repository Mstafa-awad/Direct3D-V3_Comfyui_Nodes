"""Quantized non-causal attention for head_dim 96 (SageAttention2-style), written for SM120 / Triton 3.x.

QK^T : INT8 with per-token scales for Q and K (Q pre-scaled by softmax_scale*log2(e)); K is mean-smoothed
       over the sequence first (softmax is invariant to the per-query constant this removes).
PV   : pv="fp16"   -> P and V in fp16, fp32 accumulate
       pv="fp16acc"-> P and V in fp16, fp16 accumulate per tile, fp32 running sum
       pv="fp8"    -> P in e4m3 (static scale 448), V in e4m3 per-channel scale after mean smoothing
The 96-wide head is processed as a 64 + 32 split so no tensor-core work is wasted on padding.
Layout: q, k, v [B, H, N, 96] with stride(-1) == 1 (any other strides).  Output [B, H, N, 96] in q.dtype.
"""
import torch
import triton
import triton.language as tl

LOG2E = 1.4426950408889634


@triton.jit
def _quant_rows_int8(X, Out, Scale, N, sxb, sxh, sxn, sob, soh, son, multiplier,
                     H: tl.constexpr, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    bh = tl.program_id(1)
    b = bh // H
    h = bh % H
    rows = pid * BLOCK + tl.arange(0, BLOCK)
    c0 = tl.arange(0, 64)
    c1 = 64 + tl.arange(0, 32)
    m = rows < N
    base = X + b.to(tl.int64) * sxb + h.to(tl.int64) * sxh + rows[:, None].to(tl.int64) * sxn
    x0 = tl.load(base + c0[None, :], mask=m[:, None], other=0.0).to(tl.float32) * multiplier
    x1 = tl.load(base + c1[None, :], mask=m[:, None], other=0.0).to(tl.float32) * multiplier
    amax = tl.maximum(tl.max(tl.abs(x0), 1), tl.max(tl.abs(x1), 1))
    scale = tl.maximum(amax, 1e-20) / 127.0
    q0 = x0 / scale[:, None]
    q1 = x1 / scale[:, None]
    q0 = tl.extra.cuda.libdevice.rint(q0).to(tl.int8)
    q1 = tl.extra.cuda.libdevice.rint(q1).to(tl.int8)
    obase = Out + b.to(tl.int64) * sob + h.to(tl.int64) * soh + rows[:, None].to(tl.int64) * son
    tl.store(obase + c0[None, :], q0, mask=m[:, None])
    tl.store(obase + c1[None, :], q1, mask=m[:, None])
    tl.store(Scale + bh.to(tl.int64) * N + rows, scale, mask=m)


def _int8_rows(x, multiplier, block=64):
    B, H, N, D = x.shape
    out = torch.empty((B, H, N, D), device=x.device, dtype=torch.int8)
    scale = torch.empty((B * H, N), device=x.device, dtype=torch.float32)
    grid = (triton.cdiv(N, block), B * H)
    _quant_rows_int8[grid](x, out, scale, N, x.stride(0), x.stride(1), x.stride(2),
                           out.stride(0), out.stride(1), out.stride(2), multiplier, H=H, BLOCK=block)
    return out, scale


def _attn_configs():
    cfgs = []
    for bm, bn, w, s in [(128, 64, 4, 3), (128, 64, 8, 3), (128, 128, 8, 3), (128, 64, 4, 4),
                         (64, 64, 4, 4), (128, 128, 8, 2), (64, 128, 4, 3), (128, 32, 4, 4)]:
        cfgs.append(triton.Config({"BM": bm, "BN": bn}, num_warps=w, num_stages=s))
    return cfgs


@triton.jit
def _attn_fwd_kernel(Q, K, V, QS, KS, VS, VM, O, NQ, NK,
              sqb, sqh, sqn, skb, skh, skn, svb, svh, svn, sob, soh, son,
              H: tl.constexpr, PV: tl.constexpr, QK: tl.constexpr, BM: tl.constexpr, BN: tl.constexpr):
    pid = tl.program_id(0)
    bh = tl.program_id(1)
    b = bh // H
    h = bh % H
    rm = pid * BM + tl.arange(0, BM)
    rn = tl.arange(0, BN)
    c0 = tl.arange(0, 64)
    c1 = 64 + tl.arange(0, 32)
    qmask = rm < NQ
    qbase = Q + b.to(tl.int64) * sqb + h.to(tl.int64) * sqh + rm[:, None].to(tl.int64) * sqn
    q0 = tl.load(qbase + c0[None, :], mask=qmask[:, None], other=0)
    q1 = tl.load(qbase + c1[None, :], mask=qmask[:, None], other=0)
    qs = tl.load(QS + bh.to(tl.int64) * NQ + rm, mask=qmask, other=0.0)
    kbase = K + b.to(tl.int64) * skb + h.to(tl.int64) * skh
    vbase = V + b.to(tl.int64) * svb + h.to(tl.int64) * svh
    ksbase = KS + bh.to(tl.int64) * NK
    m_i = tl.zeros([BM], dtype=tl.float32) - float("inf")
    l_i = tl.zeros([BM], dtype=tl.float32)
    acc0 = tl.zeros([BM, 64], dtype=tl.float32)
    acc1 = tl.zeros([BM, 32], dtype=tl.float32)
    for start in range(0, NK, BN):
        kn = start + rn
        kmask = kn < NK
        kptr = kbase + kn[None, :].to(tl.int64) * skn
        k0 = tl.load(kptr + c0[:, None], mask=kmask[None, :], other=0)
        k1 = tl.load(kptr + c1[:, None], mask=kmask[None, :], other=0)
        ks = tl.load(ksbase + kn, mask=kmask, other=0.0)
        if QK == 0:
            qk = tl.dot(q0, k0).to(tl.float32) + tl.dot(q1, k1).to(tl.float32)
            qk = qk * qs[:, None] * ks[None, :]
        elif QK == 1:
            qk = tl.dot(q1, k1, tl.dot(q0, k0))
        else:
            qk = tl.dot(q0, k0, out_dtype=tl.float16).to(tl.float32) + tl.dot(q1, k1, out_dtype=tl.float16).to(tl.float32)
        qk = tl.where(kmask[None, :], qk, float("-inf"))
        m_new = tl.maximum(m_i, tl.max(qk, 1))
        p = tl.math.exp2(qk - m_new[:, None])
        alpha = tl.math.exp2(m_i - m_new)
        l_i = l_i * alpha + tl.sum(p, 1)
        acc0 = acc0 * alpha[:, None]
        acc1 = acc1 * alpha[:, None]
        vptr = vbase + kn[:, None].to(tl.int64) * svn
        v0 = tl.load(vptr + c0[None, :], mask=kmask[:, None], other=0.0)
        v1 = tl.load(vptr + c1[None, :], mask=kmask[:, None], other=0.0)
        if PV == 3:  # int8 P (per-row tile scale) x int8 V (per-channel), int32 accumulate per tile
            pmax = tl.maximum(tl.max(p, 1), 1e-30)
            pq = tl.extra.cuda.libdevice.rint(p * (127.0 / pmax)[:, None]).to(tl.int8)
            rs = pmax / 127.0
            acc0 += tl.dot(pq, v0).to(tl.float32) * rs[:, None]
            acc1 += tl.dot(pq, v1).to(tl.float32) * rs[:, None]
        elif PV == 2:  # fp8
            p8 = (p * 448.0).to(tl.float8e4nv)
            acc0 = tl.dot(p8, v0, acc0)
            acc1 = tl.dot(p8, v1, acc1)
        elif PV == 1:  # fp16 accumulate within the tile
            p16 = p.to(tl.float16)
            acc0 += tl.dot(p16, v0, out_dtype=tl.float16).to(tl.float32)
            acc1 += tl.dot(p16, v1, out_dtype=tl.float16).to(tl.float32)
        else:
            p16 = p.to(tl.float16)
            acc0 = tl.dot(p16, v0, acc0)
            acc1 = tl.dot(p16, v1, acc1)
        m_i = m_new
    out0 = acc0 / l_i[:, None]
    out1 = acc1 / l_i[:, None]
    if PV == 3:
        vs0 = tl.load(VS + bh.to(tl.int64) * 96 + c0)
        vs1 = tl.load(VS + bh.to(tl.int64) * 96 + c1)
        vm0 = tl.load(VM + bh.to(tl.int64) * 96 + c0)
        vm1 = tl.load(VM + bh.to(tl.int64) * 96 + c1)
        out0 = out0 * vs0[None, :] + vm0[None, :]
        out1 = out1 * vs1[None, :] + vm1[None, :]
    if PV == 2:
        vs0 = tl.load(VS + bh.to(tl.int64) * 96 + c0)
        vs1 = tl.load(VS + bh.to(tl.int64) * 96 + c1)
        vm0 = tl.load(VM + bh.to(tl.int64) * 96 + c0)
        vm1 = tl.load(VM + bh.to(tl.int64) * 96 + c1)
        out0 = out0 * (vs0 / 448.0)[None, :] + vm0[None, :]
        out1 = out1 * (vs1 / 448.0)[None, :] + vm1[None, :]
    obase = O + b.to(tl.int64) * sob + h.to(tl.int64) * soh + rm[:, None].to(tl.int64) * son
    tl.store(obase + c0[None, :], out0.to(O.dtype.element_ty), mask=qmask[:, None])
    tl.store(obase + c1[None, :], out1.to(O.dtype.element_ty), mask=qmask[:, None])


_attn_fwd = triton.autotune(configs=_attn_configs(), key=["NQ", "NK", "PV", "QK", "H"])(_attn_fwd_kernel)

PV_MODES = {"fp16": 0, "fp16acc": 1, "fp8": 2, "int8": 3}


QK_MODES = {"int8": 0, "fp16": 1, "fp16acc": 2}
# (qk, pv) -> config chosen offline by tune_attn.py on the RTX 5050 (SM120); avoids runtime autotuning.
FIXED_CONFIGS = {
    ("int8", "fp16acc"): triton.Config({"BM": 128, "BN": 64}, num_warps=4, num_stages=3),
    ("fp16acc", "fp16acc"): triton.Config({"BM": 128, "BN": 64}, num_warps=8, num_stages=3),
}


def attention(q, k, v, pv="fp16acc", qk="int8", scale=None, smooth_k=True, out=None, _config=None):
    """q, k, v: [B, H, N, 96] fp16, last dim contiguous. Returns [B, H, NQ, 96] fp16 (contiguous)."""
    assert q.shape[-1] == 96 and q.stride(-1) == k.stride(-1) == v.stride(-1) == 1
    B, H, NQ, _ = q.shape
    NK = k.shape[2]
    if scale is None:
        scale = 96 ** -0.5
    if smooth_k:
        k = k - k.mean(dim=2, keepdim=True)
    qmode = QK_MODES[qk]
    if qmode == 0:
        qi, qs = _int8_rows(q, scale * LOG2E)
        ki, ks = _int8_rows(k, 1.0)
    else:
        qi = (q * (scale * LOG2E)).to(torch.float16)
        ki = k if k.dtype == torch.float16 else k.half()
        qs = ks = torch.empty(1, device=q.device)
    del k
    mode = PV_MODES[pv]
    if mode == 2:
        vm = v.float().mean(dim=2, keepdim=True)              # [B,H,1,96]
        vc = v.float() - vm
        vs = vc.abs().amax(dim=2, keepdim=True).clamp_min(1e-12) / 448.0
        v_in = (vc / vs).to(torch.float8_e4m3fn)
        del vc
        vs_flat = vs.reshape(B * H, 96).contiguous()   # kernel: (448*P) @ (vc/vs) / l * vs / 448
        vm_flat = vm.reshape(B * H, 96).contiguous()
    elif mode == 3:
        vm = v.float().mean(dim=2, keepdim=True)
        vc = v.float() - vm
        vs = vc.abs().amax(dim=2, keepdim=True).clamp_min(1e-12) / 127.0
        v_in = torch.round(vc / vs).clamp_(-127, 127).to(torch.int8)
        del vc
        vs_flat = vs.reshape(B * H, 96).contiguous()
        vm_flat = vm.reshape(B * H, 96).contiguous()
    else:
        v_in = v
        vs_flat = vm_flat = qs
    o = out if out is not None else torch.empty((B, H, NQ, 96), device=q.device, dtype=q.dtype)
    args = (qi, ki, v_in, qs, ks, vs_flat, vm_flat, o, NQ, NK,
            qi.stride(0), qi.stride(1), qi.stride(2), ki.stride(0), ki.stride(1), ki.stride(2),
            v_in.stride(0), v_in.stride(1), v_in.stride(2), o.stride(0), o.stride(1), o.stride(2))
    cfg = _config if _config is not None else FIXED_CONFIGS.get((qk, pv))
    if cfg is None:
        grid = lambda meta: (triton.cdiv(NQ, meta["BM"]), B * H)
        _attn_fwd[grid](*args, H=H, PV=mode, QK=qmode)
    else:
        kw = dict(cfg.kwargs)
        _attn_fwd_kernel[(triton.cdiv(NQ, kw["BM"]), B * H)](*args, H=H, PV=mode, QK=qmode, **kw,
                                                              num_warps=cfg.num_warps, num_stages=cfg.num_stages)
    return o
