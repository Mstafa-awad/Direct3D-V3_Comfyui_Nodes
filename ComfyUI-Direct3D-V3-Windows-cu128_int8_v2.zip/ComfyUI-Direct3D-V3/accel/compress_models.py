"""Shrink the Direct3D-V3 checkpoints on disk.

Geometry stages (512 / 1024 / 1536): every large Linear weight is stored as INT8 with one FP32 scale per group of
32 input weights (quantized from the FP16 weights the worker uses); all other tensors are stored as FP16.
The worker's loader (direct3d/models/checkpoint.py) rebuilds FP16 weights at load time, so every accel_mode keeps
working. Measured effect at 1024: about 1.6x the normal FP16 rounding noise (CFG error 0.15-0.18% per step versus
0.10% for cuDNN-vs-efficient). ~5.0 GB -> ~1.4 GB per stage.

DINOv3 image encoder: stored as FP16 (the worker already runs it in FP16, so output is bit-identical). 3.4 -> 1.7 GB.

Usage (from the node folder):  .runtime\\Scripts\\python.exe -m accel.compress_models [--stages 512 1024 1536]
New files are written as model.safetensors.w8g32 / model.safetensors.fp16 next to the originals; the originals are
not touched. Swap them in with --replace after checking.

Made by @MostAadTech (https://github.com/Mstafa-awad/Direct3D-V3_Comfyui_Nodes)
"""
import argparse
import json
import os
import time
from pathlib import Path

import torch
from safetensors import safe_open
from safetensors.torch import save_file

ROOT = Path(__file__).resolve().parents[1]
MODELS = ROOT / "models" / "Direct3D-V3"
GROUP = 32
FORMAT = "direct3d-v3-w8g32"


def quantizable(key, tensor):
    return (key.endswith(".weight") and tensor.dim() == 2 and tensor.numel() >= 65536
            and tensor.shape[1] % GROUP == 0)


def quantize(weight16, device):
    """INT8 + per-group FP32 scale; mirrors direct3d.models.checkpoint.dequantize_w8g32."""
    w = weight16.to(device).float()
    out_f, in_f = w.shape
    g = w.view(out_f, in_f // GROUP, GROUP)
    s = g.abs().amax(dim=2, keepdim=True).clamp_min(1e-12) / 127
    q = (g / s).round().clamp(-127, 127).to(torch.int8).view(out_f, in_f)
    return q.cpu(), s.view(out_f, in_f // GROUP).cpu()


def compress_stage(folder, device):
    src = folder / "model.safetensors"
    dst = folder / "model.safetensors.w8g32"
    out, n_q = {}, 0
    with safe_open(str(src), framework="pt", device="cpu") as archive:
        meta = archive.metadata() or {}
        if meta.get("format") == FORMAT:
            print(f"{src} is already compressed; skipping")
            return None
        for key in archive.keys():
            t = archive.get_tensor(key)
            if t.is_floating_point():
                t = t.to(torch.float16)          # the worker's load dtype
            if quantizable(key, t):
                q, s = quantize(t, device)
                out[key + ".q8"] = q
                out[key + ".s"] = s
                n_q += 1
            else:
                out[key] = t.contiguous()
    save_file(out, str(dst), metadata={"format": FORMAT, "group": str(GROUP), "version": "1",
                                       "made_by": "@MostAadTech"})
    return dst, n_q


def compress_dino(folder):
    src = folder / "model.safetensors"
    dst = folder / "model.safetensors.fp16"
    out = {}
    with safe_open(str(src), framework="pt", device="cpu") as archive:
        for key in archive.keys():
            t = archive.get_tensor(key)
            out[key] = (t.to(torch.float16) if t.is_floating_point() else t).contiguous()
    save_file(out, str(dst), metadata={"format": "pt"})
    return dst


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stages", nargs="*", type=int, default=[512, 1024, 1536])
    ap.add_argument("--no-dino", action="store_true")
    ap.add_argument("--replace", action="store_true", help="swap the new files in and DELETE the originals")
    args = ap.parse_args()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    index = json.loads((MODELS / "model_index.json").read_text(encoding="utf-8-sig"))
    targets = [MODELS / index[f"shape_transformers_{s}"] for s in args.stages]
    dino = MODELS / index["image_encoder"].lstrip("./")
    if args.replace:
        for folder, suffix in [(f, ".w8g32") for f in targets] + ([] if args.no_dino else [(dino, ".fp16")]):
            new = folder / ("model.safetensors" + suffix)
            if new.is_file():
                os.replace(new, folder / "model.safetensors")
                print("replaced", folder / "model.safetensors")
        return
    for folder in targets:
        t = time.perf_counter()
        result = compress_stage(folder, device)
        if result:
            dst, n_q = result
            print(f"{dst}: {n_q} int8 matrices, {dst.stat().st_size / 2**30:.2f} GiB "
                  f"(was {(folder / 'model.safetensors').stat().st_size / 2**30:.2f} GiB), {time.perf_counter() - t:.0f} s")
    if not args.no_dino:
        dst = compress_dino(dino)
        print(f"{dst}: {dst.stat().st_size / 2**30:.2f} GiB (was {(dino / 'model.safetensors').stat().st_size / 2**30:.2f} GiB)")


if __name__ == "__main__":
    main()
