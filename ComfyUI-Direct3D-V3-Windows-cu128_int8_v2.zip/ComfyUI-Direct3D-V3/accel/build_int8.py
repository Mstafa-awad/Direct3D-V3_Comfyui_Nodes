"""Write a pre-quantized INT8 checkpoint for the 1536 stage (smaller on disk, faster to load).

Usage (from the node folder):
  .runtime\\Scripts\\python.exe -m accel.build_int8 --mode fast
  .runtime\\Scripts\\python.exe -m accel.build_int8 --mode fastest

The file is written next to the original as model_int8_<mode>.safetensors. It holds exactly the tensors the
worker would create at load time (same conversion code), so results are identical; the FP32 original is kept.
"""
import argparse
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "vendor" / "Direct3D-V3")]


def main():
    import torch
    import accel
    from direct3d.models.checkpoint import load_denoiser

    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=("fast", "fastest"), required=True)
    ap.add_argument("--folder", default=str(ROOT / "models" / "Direct3D-V3" / "shape_transformers_1536"))
    args = ap.parse_args()
    folder = Path(args.folder)
    config = json.loads((folder / "config.json").read_text())
    if config["resolution"] != 1536:
        raise SystemExit("INT8 calibration exists only for the 1536 stage.")
    start = time.perf_counter()
    with torch.inference_mode():
        model = load_denoiser(folder / "model.safetensors", config["denoiser"], torch.float16,
                              device=torch.device("cuda"), stream_blocks=False)
        accel.convert_int8(model, args.mode)
        out = accel.int8_checkpoint_path(folder, args.mode)
        tmp = out.with_suffix(".tmp")
        size = accel.save_int8_checkpoint(model, tmp, args.mode)
        tmp.replace(out)
    print(f"Wrote {out} ({out.stat().st_size / 2**30:.2f} GiB, tensors {size / 2**30:.2f} GiB) "
          f"in {time.perf_counter() - start:.1f} s")


if __name__ == "__main__":
    main()
