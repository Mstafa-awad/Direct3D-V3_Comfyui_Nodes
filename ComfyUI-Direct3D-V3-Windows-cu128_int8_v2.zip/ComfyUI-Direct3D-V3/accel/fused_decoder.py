"""Fused PixelAttentionBlock (Direct3D-V3 pixel decoder) — same math, far fewer passes.

* adaLN projection split: pass 1 computes only (shift, scale) rows, pass 2 only (gate, shift2, scale2, mlp_gate),
  instead of the full 6-way projection twice.
* LayerNorm over the 8 pixel channels + modulation fused into one Triton kernel (fp32 statistics, fp16 rounding
  at the same points as the PyTorch code: LN result, (1+scale), product, sum).
* Pass 2 residual (x + gate*unproj) fused with the second LayerNorm + modulation.
"""
import torch
import triton
import triton.language as tl


@triton.jit
def _ln8_mod(X, SS, W, B, OUT, RES, G, U, P, eps,
             HAS_RES: tl.constexpr, ROWS: tl.constexpr):
    """Rows of 8 channels. SS holds [shift(8), scale(8)] per row (stride 16 per pixel row).
    If HAS_RES: x = X + G*U (fp16 rounding per op), stored to RES, then LN/mod applied to it."""
    pid = tl.program_id(0)
    r = pid * ROWS + tl.arange(0, ROWS)
    c = tl.arange(0, 8)
    m = (r < P)[:, None]
    off = r[:, None].to(tl.int64) * 8 + c[None, :]
    x = tl.load(X + off, mask=m, other=0.0)
    if HAS_RES:
        g = tl.load(G + r[:, None].to(tl.int64) * 32 + c[None, :], mask=m, other=0.0)
        u = tl.load(U + off, mask=m, other=0.0)
        gu = (g.to(tl.float32) * u.to(tl.float32)).to(tl.float16)
        x = (x.to(tl.float32) + gu.to(tl.float32)).to(tl.float16)
        tl.store(RES + off, x, mask=m)
    xf = x.to(tl.float32)
    mean = tl.sum(xf, 1) / 8.0
    d = xf - mean[:, None]
    var = tl.sum(d * d, 1) / 8.0
    rstd = 1.0 / tl.sqrt(var + eps)
    w = tl.load(W + c).to(tl.float32)
    b = tl.load(B + c).to(tl.float32)
    ln = (d * rstd[:, None] * w[None, :] + b[None, :]).to(tl.float16)
    if HAS_RES:
        sbase = SS + r[:, None].to(tl.int64) * 32
        shift = tl.load(sbase + 8 + c[None, :], mask=m, other=0.0)
        scale = tl.load(sbase + 16 + c[None, :], mask=m, other=0.0)
    else:
        sbase = SS + r[:, None].to(tl.int64) * 16
        shift = tl.load(sbase + c[None, :], mask=m, other=0.0)
        scale = tl.load(sbase + 8 + c[None, :], mask=m, other=0.0)
    one_plus = (1.0 + scale.to(tl.float32)).to(tl.float16)
    prod = (one_plus.to(tl.float32) * ln.to(tl.float32)).to(tl.float16)
    out = (prod.to(tl.float32) + shift.to(tl.float32)).to(tl.float16)
    tl.store(OUT + off, out, mask=m)


def _ln8_mod_call(x, ss, norm, out, res=None, gate_src=None, unproj=None):
    P = x.numel() // 8
    rows = 256
    _ln8_mod[(triton.cdiv(P, rows),)](x, ss, norm.weight, norm.bias, out,
                                       res if res is not None else out,
                                       gate_src if gate_src is not None else x,
                                       unproj if unproj is not None else x,
                                       P, norm.eps, HAS_RES=res is not None, ROWS=rows, num_warps=4)


def _split_linear(linear, patches, channels, which):
    """Rows of the 6-way adaLN projection for the given modulation indices, as a new weight/bias."""
    w = linear.weight.view(patches, 6, channels, -1)[:, which].reshape(-1, linear.in_features)
    b = linear.bias.view(patches, 6, channels)[:, which].reshape(-1)
    return w.contiguous(), b.contiguous()


def install(model, chunk_rows=4096):
    """Bind the fused forward to each eligible PixelAttentionBlock of `model` (8 channels, fp16 run)."""
    import types
    import torch.nn.functional as F

    eligible = []
    for block in model.decoder.res_blocks:
        lin = block.adaLN_modulation[1]
        if (block.channels != 8 or not isinstance(lin, torch.nn.Linear) or lin.bias is None
                or lin.out_features != block.patch_size ** 3 * 6 * block.channels):
            continue
        eligible.append(block)
    for block in eligible:
        patches, ch = block.patch_size ** 3, block.channels
        lin = block.adaLN_modulation[1]
        block._ada1 = _split_linear(lin, patches, ch, [0, 1])
        block._ada2 = _split_linear(lin, patches, ch, [2, 3, 4, 5])
        # Drop the original 6-way weights to keep memory flat.
        block.adaLN_modulation[1].weight = None
        block.adaLN_modulation[1].bias = None

    def forward(self, x, y, index, *, window_size, window_cache):
        patches = self.patch_size ** 3
        n_all = len(x)
        compact = x.new_empty(n_all, self.compact_proj.out_features)
        w1, b1 = self._ada1
        w2, b2 = self._ada2
        for start in range(0, n_all, chunk_rows):
            part = slice(start, start + chunk_rows)
            ss = F.linear(F.silu(y[part]), w1, b1)                      # [n, patches*2*ch] = (shift, scale)
            normalized = torch.empty_like(x[part])
            _ln8_mod_call(x[part], ss, self.norm1, normalized)
            compact[part] = self.compact_proj(normalized.flatten(1))
            del ss, normalized
        attended = self.attn1(compact, index, window_size=window_size, window_cache=window_cache)
        del compact
        for start in range(0, n_all, chunk_rows):
            part = slice(start, start + chunk_rows)
            mod = F.linear(F.silu(y[part]), w2, b2)                     # [n, patches*4*ch] = gate, shift, scale, mlp_gate
            unproj = self.compact_unproj(attended[part])
            residual = torch.empty_like(x[part])
            h = torch.empty_like(x[part])
            _ln8_mod_call(x[part], mod, self.norm2, h, res=residual, gate_src=mod, unproj=unproj)
            del unproj
            m = self.mlp(h)
            del h
            mlp_gate = mod.view(-1, patches, 4, self.channels)[:, :, 3]
            x[part] = residual + mlp_gate * m
            del mod, residual, m
        return x

    for block in eligible:
        block.forward = types.MethodType(forward, block)
    return len(eligible)
