"""Drop-in replacements for nn.Linear at inference on SM120.

Int8Linear : W8A8 — int8 weights (per-output-channel scale), int8 activations (dynamic per-token scale),
             int32 accumulate, scales + bias applied in the GEMM epilogue, fp16 output.
             Optional SmoothQuant factor s[K] (x/s, W*s) migrates activation outliers into the weights.
Fp16AccLinear : unchanged fp16 weights; fp16 tensor-core accumulation within each K tile, fp32 across tiles.
"""
import torch
import triton
import triton.language as tl
from torch import nn

from . import triton_gemm


@triton.jit
def _quant_tokens(X, Q, S, INV, M, K, sxm, sqm, HAS_INV: tl.constexpr, BK: tl.constexpr, ROWS: tl.constexpr):
    pid = tl.program_id(0)
    rows = pid * ROWS + tl.arange(0, ROWS)
    rmask = rows < M
    amax = tl.zeros([ROWS], dtype=tl.float32)
    for k in range(0, K, BK):
        cols = k + tl.arange(0, BK)
        m = rmask[:, None] & (cols[None, :] < K)
        x = tl.load(X + rows[:, None].to(tl.int64) * sxm + cols[None, :], mask=m, other=0.0).to(tl.float32)
        if HAS_INV:
            x = x * tl.load(INV + cols, mask=cols < K, other=0.0)[None, :]
        amax = tl.maximum(amax, tl.max(tl.abs(x), 1))
    scale = tl.maximum(amax, 1e-12) / 127.0
    for k in range(0, K, BK):
        cols = k + tl.arange(0, BK)
        m = rmask[:, None] & (cols[None, :] < K)
        x = tl.load(X + rows[:, None].to(tl.int64) * sxm + cols[None, :], mask=m, other=0.0).to(tl.float32)
        if HAS_INV:
            x = x * tl.load(INV + cols, mask=cols < K, other=0.0)[None, :]
        q = tl.extra.cuda.libdevice.rint(x / scale[:, None]).to(tl.int8)
        tl.store(Q + rows[:, None].to(tl.int64) * sqm + cols[None, :], q, mask=m)
    tl.store(S + rows, scale, mask=rmask)


def quant_tokens(x, inv_smooth=None):
    M, K = x.shape
    q = torch.empty((M, K), device=x.device, dtype=torch.int8)
    s = torch.empty((M,), device=x.device, dtype=torch.float32)
    rows = 16
    _quant_tokens[(triton.cdiv(M, rows),)](x, q, s, inv_smooth if inv_smooth is not None else s, M, K,
                                           x.stride(0), q.stride(0), HAS_INV=inv_smooth is not None,
                                           BK=256, ROWS=rows, num_warps=4)
    return q, s


class Int8Linear(nn.Module):
    def __init__(self, linear, smooth=None, chunk_rows=65536):
        super().__init__()
        w = linear.weight.detach().float()
        if smooth is not None:
            smooth = smooth.float().to(w.device)
            w = w * smooth[None, :]
            self.register_buffer("inv_smooth", (1.0 / smooth).contiguous())
        else:
            self.inv_smooth = None
        scale = w.abs().amax(dim=1).clamp_min(1e-12) / 127.0
        self.register_buffer("qweight", torch.round(w / scale[:, None]).clamp(-127, 127).to(torch.int8).contiguous())
        self.register_buffer("wscale", scale.contiguous())
        self.register_buffer("bias", None if linear.bias is None else linear.bias.detach().half().contiguous())
        # Model fast paths inspect .weight.dtype; report the compute dtype without storing fp16 weights.
        self.register_buffer("weight", torch.empty(0, dtype=torch.float16, device=w.device), persistent=False)
        self.in_features, self.out_features = linear.in_features, linear.out_features
        self.chunk_rows = chunk_rows

    @classmethod
    def shell(cls, in_features, out_features, has_bias, has_smooth, chunk_rows=65536):
        """Empty meta-device module with the saved layout; filled by load_state_dict(assign=True)."""
        self = cls.__new__(cls)
        nn.Module.__init__(self)
        meta = torch.device("meta")
        self.register_buffer("qweight", torch.empty((out_features, in_features), dtype=torch.int8, device=meta))
        self.register_buffer("wscale", torch.empty((out_features,), dtype=torch.float32, device=meta))
        self.register_buffer("bias", torch.empty((out_features,), dtype=torch.float16, device=meta) if has_bias else None)
        if has_smooth:
            self.register_buffer("inv_smooth", torch.empty((in_features,), dtype=torch.float32, device=meta))
        else:
            self.inv_smooth = None
        self.register_buffer("weight", torch.empty(0, dtype=torch.float16, device=meta), persistent=False)
        self.in_features, self.out_features = in_features, out_features
        self.chunk_rows = chunk_rows
        return self

    def forward(self, x):
        shape = x.shape
        x2 = x.reshape(-1, shape[-1])
        if x2.dtype != torch.float16:
            x2 = x2.half()
        if x2.stride(-1) != 1:
            x2 = x2.contiguous()
        out = torch.empty((len(x2), self.out_features), device=x.device, dtype=torch.float16)
        for start in range(0, len(x2), self.chunk_rows):
            part = slice(start, start + self.chunk_rows)
            q, s = quant_tokens(x2[part], self.inv_smooth)
            triton_gemm.gemm(q, self.qweight, s, self.wscale, self.bias, out=out[part])
            del q, s
        return out.reshape(*shape[:-1], self.out_features)


class Fp16AccLinear(nn.Module):
    def __init__(self, linear):
        super().__init__()
        self.register_buffer("w", linear.weight.detach().half().contiguous())
        self.register_buffer("bias", None if linear.bias is None else linear.bias.detach().half().contiguous())
        self.register_buffer("weight", torch.empty(0, dtype=torch.float16, device=self.w.device), persistent=False)
        self.in_features, self.out_features = linear.in_features, linear.out_features

    def forward(self, x):
        shape = x.shape
        x2 = x.reshape(-1, shape[-1])
        if x2.dtype != torch.float16:
            x2 = x2.half()
        if x2.stride(-1) != 1:
            x2 = x2.contiguous()
        out = triton_gemm.gemm(x2, self.w, bias=self.bias, acc16=True)
        return out.reshape(*shape[:-1], self.out_features)


def convert(module, make, predicate):
    count = 0
    for name, child in list(module.named_modules()):
        for attr, sub in list(child.named_children()):
            full = f"{name}.{attr}" if name else attr
            if isinstance(sub, nn.Linear) and predicate(full, sub):
                setattr(child, attr, make(full, sub))
                count += 1
    return count
