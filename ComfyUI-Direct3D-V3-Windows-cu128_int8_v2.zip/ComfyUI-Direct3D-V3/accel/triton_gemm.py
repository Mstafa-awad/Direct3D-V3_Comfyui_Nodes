"""Triton GEMM C[M,N] = A[M,K] @ B[N,K]^T with per-row (A) and per-column (B) scales in the epilogue.

Supports fp16 inputs (fp32 or fp16 accumulate) and fp8 e4m3 inputs (fp32 accumulate).
"""
import torch
import triton
import triton.language as tl


def _configs():
    out = []
    for bm, bn, bk, w, s in [(128, 128, 64, 8, 3), (128, 128, 128, 8, 3), (128, 256, 64, 8, 3),
                             (128, 64, 64, 4, 4), (64, 128, 64, 4, 4), (128, 128, 64, 4, 4),
                             (256, 128, 64, 8, 3), (128, 256, 128, 8, 2), (128, 128, 128, 4, 3)]:
        out.append(triton.Config({"BM": bm, "BN": bn, "BK": bk, "GROUP": 8}, num_warps=w, num_stages=s))
    return out


@triton.autotune(configs=_configs(), key=["N", "K", "ACC16", "HAS_BIAS", "INT8"])
@triton.jit
def _gemm(A, B, C, SA, SB, BIAS, M, N, K, sam, sbn, scm,
          ACC16: tl.constexpr, HAS_SCALE: tl.constexpr, HAS_BIAS: tl.constexpr, INT8: tl.constexpr,
          BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr, GROUP: tl.constexpr):
    pid = tl.program_id(0)
    num_m = tl.cdiv(M, BM)
    num_n = tl.cdiv(N, BN)
    group = GROUP * num_n
    gid = pid // group
    first_m = gid * GROUP
    size_m = min(num_m - first_m, GROUP)
    pm = first_m + (pid % group) % size_m
    pn = (pid % group) // size_m
    rm = pm * BM + tl.arange(0, BM)
    rn = pn * BN + tl.arange(0, BN)
    rk = tl.arange(0, BK)
    a_ptr = A + rm[:, None].to(tl.int64) * sam + rk[None, :]
    b_ptr = B + rn[None, :].to(tl.int64) * sbn + rk[:, None]
    if INT8:
        acc = tl.zeros((BM, BN), dtype=tl.int32)
    elif ACC16:
        acc32 = tl.zeros((BM, BN), dtype=tl.float32)
    else:
        acc = tl.zeros((BM, BN), dtype=tl.float32)
    for k in range(0, K, BK):
        a = tl.load(a_ptr, mask=(rm[:, None] < M) & (rk[None, :] + k < K), other=0)
        b = tl.load(b_ptr, mask=(rn[None, :] < N) & (rk[:, None] + k < K), other=0)
        if INT8:
            acc = tl.dot(a, b, acc)
        elif ACC16:
            # fp16 accumulation inside one BK tile only; tiles are summed in fp32.
            acc32 += tl.dot(a, b, out_dtype=tl.float16).to(tl.float32)
        else:
            acc = tl.dot(a, b, acc)
        a_ptr += BK
        b_ptr += BK
    if ACC16 and not INT8:
        acc = acc32
    acc = acc.to(tl.float32)
    if HAS_SCALE:
        acc = acc * tl.load(SA + rm, mask=rm < M, other=0.0)[:, None] * tl.load(SB + rn, mask=rn < N, other=0.0)[None, :]
    if HAS_BIAS:
        acc = acc + tl.load(BIAS + rn, mask=rn < N, other=0.0).to(tl.float32)[None, :]
    c_ptr = C + rm[:, None].to(tl.int64) * scm + rn[None, :]
    tl.store(c_ptr, acc.to(C.dtype.element_ty), mask=(rm[:, None] < M) & (rn[None, :] < N))


def gemm(a, b, scale_a=None, scale_b=None, bias=None, acc16=False, out=None):
    """int8 inputs -> int32 accumulate; fp8 -> fp32; fp16 -> fp32 (or fp16-per-tile with acc16)."""
    M, K = a.shape
    N = b.shape[0]
    assert a.stride(1) == 1 and b.stride(1) == 1
    if out is None:
        out = torch.empty((M, N), device=a.device, dtype=torch.float16)
    has_scale = scale_a is not None
    grid = lambda meta: (triton.cdiv(M, meta["BM"]) * triton.cdiv(N, meta["BN"]),)
    _gemm[grid](a, b, out, scale_a if has_scale else a, scale_b if has_scale else a,
                bias if bias is not None else a, M, N, K, a.stride(0), b.stride(0), out.stride(0),
                ACC16=acc16, HAS_SCALE=has_scale, HAS_BIAS=bias is not None, INT8=a.dtype == torch.int8)
    return out


def candidates(a, b, a8, b8):
    sa = torch.ones(a.shape[0], device=a.device)
    sb = torch.ones(b.shape[0], device=a.device)
    yield "triton fp16 acc32", lambda: gemm(a, b)
    yield "triton fp16 acc16", lambda: gemm(a, b, acc16=True)
    yield "triton fp8 acc32 rowscale", lambda: gemm(a8, b8, sa, sb)
    ai = (a * 20).clamp(-127, 127).to(torch.int8); bi = (b * 2000).clamp(-127, 127).to(torch.int8)
    yield "triton int8 fused scale+bias", lambda: gemm(ai, bi, sa, sb, bias=torch.zeros(b.shape[0], device=a.device, dtype=torch.float16))
