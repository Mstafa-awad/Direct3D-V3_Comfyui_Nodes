"""Training-free multiview conditioning for Direct3D-V3 (front + back / left / right / top / bottom views).

Made by @MostAadTech (https://github.com/Mstafa-awad/Direct3D-V3_Comfyui_Nodes)

Direct3D-V3 is trained with the image aligned to the mesh front (+z camera, +y up). For every extra view the
stage's patch grid is turned by a quarter-turn rotation so that view's camera sits on +z, the denoiser runs there
with that view's image, and the prediction is turned back and blended per patch. Quarter turns of the symmetric
G*p grid are exact re-indexings (voxel v -> dim-1-v), so no resampling error is introduced.

Camera convention (Blender-style): azimuth counter-clockwise seen from above, 0 = front (+z), 90 = camera on +x
(shows the model's left side), 180 = back, 270 = camera on -x (model's right side); elevation 90 = top view
(front at the image's bottom edge), -90 = bottom view (front at the image's top edge).
"""
import math

import torch
import torch.nn.functional as F

VIEW_ANGLES = {
    "front": (0, 0), "back": (180, 0), "left": (90, 0), "right": (270, 0), "top": (0, 90), "bottom": (0, -90),
}


def view_turn(azimuth, elevation):
    """Integer rotation mapping the view's camera direction to +z and the image's up direction to +y."""
    a, e = math.radians(azimuth), math.radians(elevation)
    ry = torch.tensor([[math.cos(-a), 0, math.sin(-a)], [0, 1, 0], [-math.sin(-a), 0, math.cos(-a)]],
                      dtype=torch.float64)
    rx = torch.tensor([[1, 0, 0], [0, math.cos(e), -math.sin(e)], [0, math.sin(e), math.cos(e)]], dtype=torch.float64)
    turn = (rx @ ry).round().to(torch.long)
    if sorted(turn.abs().sum(0).tolist()) != [1, 1, 1] or round(torch.det(turn.double()).item()) != 1:
        raise ValueError(f"View ({azimuth}, {elevation}) is not a quarter-turn view.")
    return turn


def camera_direction(azimuth, elevation):
    a, e = math.radians(azimuth), math.radians(elevation)
    return (math.sin(a) * math.cos(e), math.sin(e), math.cos(a) * math.cos(e))


def turned(indices, turn, size):
    """indices [M,3] long in 0..size-1 -> turn @ (idx - c) + c with c = (size-1)/2, exactly in integers.

    CUDA has no integer matmul, so each output axis picks the single non-zero source column of its row.
    """
    centered = indices.long() * 2 - (size - 1)
    out = torch.empty_like(centered)
    for row in range(3):
        col = int(turn[row].abs().argmax())
        out[:, row] = centered[:, col] * int(turn[row, col])
    return (out + (size - 1)) // 2


class ViewFrame:
    """Turned patch coords and the voxel permutations for one view of one stage."""

    def __init__(self, coords, patch_size, grid, azimuth, elevation):
        self.turn = view_turn(azimuth, elevation)
        self.identity = bool(torch.equal(self.turn, torch.eye(3, dtype=torch.long)))
        device = coords.device
        self.coords = torch.cat((coords[:, :1], turned(coords[:, 1:], self.turn, grid).to(coords.dtype)), dim=1)
        p = patch_size
        i = torch.arange(p**3, device=device)
        inner = torch.stack((i // p**2, i // p % p, i % p), dim=1)
        moved = turned(inner, self.turn.to(device), p)
        # Voxel k of an original patch lands at inner position scatter[k] of the turned patch.
        self.scatter = (moved[:, 0] * p + moved[:, 1]) * p + moved[:, 2]
        self.gather = torch.empty_like(self.scatter)
        self.gather[self.scatter] = i
        # Unit direction (original frame) towards this view's camera: R^T (0, 0, 1).
        self.direction = self.turn[2].double()


def visible_from(coords3, direction, grid, tol=None):
    """Patches on the camera-facing surface layer along the view's dominant axis."""
    axis = int(direction.abs().argmax())
    sign = 1 if direction[axis] > 0 else -1
    others = [a for a in range(3) if a != axis]
    tol = max(1, round(grid / 32)) if tol is None else tol
    depth = coords3[:, axis].long() * sign
    key = coords3[:, others[0]].long() * grid + coords3[:, others[1]].long()
    top = torch.full((grid * grid,), -(1 << 30), dtype=torch.long, device=coords3.device)
    top.scatter_reduce_(0, key, depth, reduce="amax")
    return depth >= top[key] - tol


def patch_normals(vertices, faces, coords3, resolution, patch_size, scale=1.0):
    """Area-weighted outward normals of the coarse mesh per occupied patch (same normalisation as mesh_patches).

    Patches without a triangle centroid inherit the average of their occupied neighbours.
    """
    v = vertices.float()
    low, high = v.amin(0), v.amax(0)
    v = (v - (low + high) / 2) * (1.9 / (high - low).max()) * scale * 0.5
    f = faces.long()
    grid = resolution // patch_size
    import numpy as np
    # Per-cell sums with np.bincount (fixed order, float64): GPU index_add_ uses float atomics whose order varies
    # between runs, which made multiview output non-repeatable.
    acc = np.zeros((3, grid**3), dtype=np.float64)
    for chunk in f.split(4_000_000):
        tri = v[chunk]
        fn = torch.linalg.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])   # length = 2 * area
        cell = (((tri.mean(1) + 0.5) * (resolution - 1)).round().long() // patch_size).clamp(0, grid - 1)
        key = ((cell[:, 0] * grid + cell[:, 1]) * grid + cell[:, 2]).cpu().numpy()
        fn = fn.double().cpu().numpy()
        for k in range(3):
            acc[k] += np.bincount(key, weights=fn[:, k], minlength=grid**3)
        del tri, cell
    n = torch.from_numpy(acc.T.astype(np.float32)).to(v.device)
    c = coords3.long()
    flat = (c[:, 0] * grid + c[:, 1]) * grid + c[:, 2]
    dense = n.T.reshape(1, 3, grid, grid, grid)
    smooth = F.avg_pool3d(dense, 3, 1, 1).reshape(3, -1).T
    out = n[flat]
    missing = out.norm(dim=1) < 1e-12
    out[missing] = smooth[flat[missing]]
    out = out / out.norm(dim=1, keepdim=True).clamp_min(1e-12)
    # Winding differs between mesh sources: make normals point away from the centre on average.
    pos = c.float()
    if ((pos - pos.mean(0)) * out).sum() < 0:
        out = -out
    return out


def view_weights(coords3, frames, grid, *, mode="visible", priors=None, temperature=2.0, feather=1,
                 normals=None, power=2.0):
    """Per-patch weights [N, V] (sum 1). View 0 is the front."""
    n, v = len(coords3), len(frames)
    priors = torch.tensor(priors if priors is not None else [1.0] * v, dtype=torch.float32,
                          device=coords3.device).clamp_min(1e-6)
    if mode == "average":
        w = (priors / priors.sum()).expand(n, v).clone()
    elif mode == "blend":
        pos = coords3.float()
        rel = pos - pos.mean(0)
        rel = rel / rel.norm(dim=1, keepdim=True).clamp_min(1e-6)
        dirs = torch.stack([f.direction.float() for f in frames]).to(coords3.device)
        w = torch.softmax(temperature * rel @ dirs.T + priors.log(), dim=1)
    elif mode == "visible":
        vis = torch.stack([visible_from(coords3, f.direction, grid) for f in frames], dim=1).float()
        w = torch.zeros(n, v, device=coords3.device)
        w[:, 0] = vis[:, 0]
        hidden = vis[:, 0] == 0
        w[hidden, 1:] = vis[hidden, 1:] * priors[1:]
        nobody = w.sum(1) == 0
        w[nobody, 0] = 1.0
        w = w / w.sum(1, keepdim=True)
    elif mode == "facing":
        if normals is None:
            raise ValueError("facing mode needs patch normals")
        vis = torch.stack([visible_from(coords3, f.direction, grid) for f in frames], dim=1).float()
        dirs = torch.stack([f.direction.float() for f in frames]).to(coords3.device)
        facing = (normals.float() @ dirs.T).clamp_min(0).pow(power)
        w = vis * facing * priors
        nobody = w.sum(1) <= 1e-12
        w[nobody, 0] = 1.0
        w = w / w.sum(1, keepdim=True)
    else:
        raise ValueError(f"Unknown multiview mode {mode!r}")
    if feather and v > 1 and mode != "average":
        w = _feather(coords3, w, grid, feather)
    return w


def _feather(coords3, w, grid, iterations):
    """Soften view boundaries by averaging weights over occupied 3x3x3 patch neighbourhoods."""
    c = coords3.long()
    flat = (c[:, 0] * grid + c[:, 1]) * grid + c[:, 2]
    occ = torch.zeros(grid**3, device=w.device)
    occ[flat] = 1
    occ = occ.view(1, 1, grid, grid, grid)
    for _ in range(iterations):
        dense = torch.zeros(w.shape[1], grid**3, device=w.device)
        dense[:, flat] = w.T
        dense = F.avg_pool3d(dense.view(1, -1, grid, grid, grid), 3, 1, 1)
        norm = F.avg_pool3d(occ, 3, 1, 1)
        w = (dense.view(w.shape[1], -1)[:, flat] / norm.view(-1)[flat].clamp_min(1e-6)).T.contiguous()
        w = w / w.sum(1, keepdim=True).clamp_min(1e-12)
    return w


def _chunks(n, size=16384):
    for start in range(0, n, size):
        yield slice(start, start + size)


@torch.inference_mode()
def sample_views(model, coords, contexts, frames, weights, generator, *, patch_size, steps, guidance_scale,
                 cfg_interval, clamp_range=(-1.0, 1.0), resolution=None, on_sampling_step=None,
                 project_unconditional_bias=False, share_uncond=False, min_share=0.0, log=print,
                 guidance_mode="cfg", apg_eta=0.0, apg_norm_threshold=0.0, fdg_high_scale=6.0,
                 cfg_skip_last_steps=0):
    """Multiview version of direct3d.schedulers.sample_x0 with identical noise, schedule and update rule.

    contexts: list of image contexts (CPU or GPU), view 0 = front. With a single identity view this reproduces
    sample_x0 exactly. share_uncond reuses the front frame's unconditional prediction (turned) for every view.
    """
    clamp_min, clamp_max = clamp_range
    device = coords.device
    latents = torch.randn((len(coords), patch_size**3 * model.out_channels), dtype=torch.float32,
                          device=device, generator=generator)
    layout = [slice(0, len(coords))]
    timesteps = torch.linspace(0.0, 1.0, steps + 1, device=device)
    share = weights.mean(0)
    active = [i for i in range(len(frames)) if i == 0 or share[i] > min_share]
    if len(active) < len(frames):
        log(f"INFO Multiview: skipping views with <= {min_share:.1%} of patches: "
            f"{[i for i in range(len(frames)) if i not in active]}")
    single = len(active) == 1 and frames[active[0]].identity
    if not frames[active[0]].identity:
        raise ValueError("The front (identity) view must come first.")
    # At high patch counts return freed blocks between views so the allocator does not grow past VRAM.
    release = len(coords) > 80000
    w = weights.to(device=device, dtype=torch.float32)
    from direct3d.schedulers.guidance import combine, step_scale
    import os
    legacy_uncond = os.environ.get("DIRECT3D_V3_LEGACY_UNCOND") == "1"
    guide = dict(mode=guidance_mode, patch_size=patch_size, apg_eta=apg_eta,
                 apg_norm_threshold=apg_norm_threshold, fdg_high_scale=fdg_high_scale)
    times = timesteps.tolist()
    for step in range(steps):
        t, t_next = timesteps[step], timesteps[step + 1]
        timestep = t.reshape(1).to(latents.dtype)
        scale = step_scale(times[step], step, steps, guidance_scale, cfg_interval, cfg_skip_last_steps)
        blend = None
        shared_u = None
        output = None
        for v in active:
            frame = frames[v]
            cond = contexts[v].to(device, non_blocking=True)
            if frame.identity:
                x = latents
            else:
                # Turned input built in row chunks, directly in the dtype the model computes with (cond.dtype),
                # so neither a full-size gathered copy nor the model's own .to() copy is made.
                x = torch.empty(latents.shape, dtype=cond.dtype, device=device)
                for rows in _chunks(len(x)):
                    x[rows] = latents[rows][:, frame.gather]
            idx = coords if frame.identity else frame.coords
            x_cond = model(x, idx, layout, timestep, cond)
            if guidance_scale > 1 and (scale != 1.0 or legacy_uncond):
                if share_uncond and shared_u is not None:
                    # Front-frame unconditional prediction, turned into this view's voxel order chunk by chunk.
                    out = x_cond
                    for rows in _chunks(len(out)):
                        u = shared_u[rows][:, frame.gather]
                        out[rows] = combine(out[rows], u, scale, **guide)
                    del u
                else:
                    if project_unconditional_bias:
                        x_uncond = model(x, idx, layout, timestep, torch.zeros_like(cond), null_context=True)
                    else:
                        x_uncond = model(x, idx, layout, timestep, torch.zeros_like(cond))
                    out = combine(x_cond, x_uncond, scale, **guide)
                    if share_uncond and frame.identity:
                        shared_u = x_uncond
                    del x_uncond
            else:
                out = x_cond
            del x_cond, x, cond
            if single:
                output = out
                break
            weight = w[:, v:v + 1]
            if blend is None:
                # The front (identity frame) comes first: its output becomes the blend buffer in place.
                blend = out
                blend.mul_(weight.to(out.dtype))
            else:
                for rows in _chunks(len(out)):
                    blend[rows] += out[rows][:, frame.scatter] * weight[rows].to(out.dtype)
            del out
            if release:
                torch.cuda.empty_cache()
        del shared_u
        if output is None:
            output = blend
            del blend
        output = output.clamp(clamp_min, clamp_max)
        noise = torch.randn(output.shape, device=device, dtype=output.dtype, generator=generator)
        latents = output * t_next + (1 - t_next) * noise
        del output, noise
        if on_sampling_step is not None:
            on_sampling_step(resolution, step + 1, steps)
    return latents
