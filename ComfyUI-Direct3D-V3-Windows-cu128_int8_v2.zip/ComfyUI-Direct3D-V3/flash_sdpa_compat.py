"""Pure-PyTorch implementations of the 3 FlashAttention functions used by Direct3D-V3.

No monkeypatching of PyTorch or CUDA. Intended for a separate worker process.
Uses PyTorch's scaled_dot_product_attention (Flash SDPA where available).
Variable-length windows are evaluated one at a time to bound peak VRAM.
"""
import os
import sys
import types
from importlib.machinery import ModuleSpec


_cudnn_fp16 = False
_cudnn_rejected = {}
_attention_counts = {"cudnn": 0, "fallback": 0, "baseline": 0}


def attention_stats():
    """Return per-stage route counts and clear them for the next stage."""
    counts = _attention_counts.copy()
    for key in _attention_counts:
        _attention_counts[key] = 0
    return counts


def _sdpa(q, k, v):
    import torch
    import torch.nn.functional as F

    if (not _cudnn_fp16 or not q.is_cuda or q.dtype != torch.float16
            or k.dtype != q.dtype or v.dtype != q.dtype
            or min(q.shape[-2], k.shape[-2]) < 4096
            or q.shape[-1] != 96
            or (torch.is_autocast_enabled("cuda") and torch.get_autocast_dtype("cuda") != q.dtype)):
        if _cudnn_fp16:
            _attention_counts["baseline"] += 1
        return F.scaled_dot_product_attention(q, k, v, dropout_p=0.0, is_causal=False)

    from torch.nn.attention import SDPBackend, sdpa_kernel

    layout = (q.device, tuple((tensor.shape, tensor.stride()) for tensor in (q, k, v)))
    if layout not in _cudnn_rejected:
        params = torch.backends.cuda.SDPAParams(q, k, v, None, 0.0, False, False)
        try:
            with sdpa_kernel(SDPBackend.CUDNN_ATTENTION):
                if torch.backends.cuda.can_use_cudnn_attention(params):
                    result = F.scaled_dot_product_attention(q, k, v, dropout_p=0.0, is_causal=False)
                    _attention_counts["cudnn"] += 1
                    return result
                reason = "PyTorch reports that this shape or layout is unsupported"
        except torch.cuda.OutOfMemoryError:
            reason = "cuDNN ran out of workspace"
        except RuntimeError as exc:
            if not any(hint in str(exc).lower() for hint in (
                "no available kernel", "no viable backend", "no execution plans",
                "cudnn_status_not_supported", "no valid execution plan",
            )):
                raise
            reason = str(exc).splitlines()[0]
        _cudnn_rejected[layout] = reason
        if len(_cudnn_rejected) == 1:
            print(f"INFO cuDNN attention fallback: {reason}", flush=True)
    _attention_counts["fallback"] += 1
    return F.scaled_dot_product_attention(q, k, v, dropout_p=0.0, is_causal=False)


def _as_lengths(cu):
    # Synchronizes tiny offset tensors only; required to split ragged windows.
    return cu.detach().to("cpu", dtype=__import__("torch").int64).tolist()


def _attention(q, k, v):
    # Q/K/V: [tokens, heads, dim] => [1, heads, tokens, dim]
    a, b, c = (t.permute(1, 0, 2).unsqueeze(0) for t in (q, k, v))
    result = _sdpa(a, b, c)
    return result.squeeze(0).permute(1, 0, 2).contiguous()


def flash_attn_qkvpacked_func(qkv, *args, **kwargs):
    # [batch, seq, 3, heads, dim]
    q, k, v = qkv.unbind(2)
    a, b, c = (tensor.permute(0, 2, 1, 3) for tensor in (q, k, v))
    return _sdpa(a, b, c).permute(0, 2, 1, 3).contiguous()


def flash_attn_varlen_qkvpacked_func(qkv, cu_seqlens, max_seqlen, *args, **kwargs):
    """Batched ragged window attention with a ~4096-token packing target.

    Packing contiguous groups of windows instead of calling SDPA per window
    avoids thousands of tiny CUDA launches on Windows. Padding masks ensure
    that tokens in different windows never attend to each other.
    """
    import torch
    import torch.nn.functional as F
    if not len(qkv):
        return qkv.new_empty((0, qkv.shape[2], qkv.shape[3]))
    bounds = _as_lengths(cu_seqlens)
    if (bounds == [0, len(qkv)] and max_seqlen == len(qkv) and not args and not kwargs
            and qkv.is_cuda and qkv.is_contiguous() and qkv.shape[1:] == (3, 8, 96)
            and qkv.dtype in (torch.float16, torch.bfloat16)
            and (not torch.is_autocast_enabled("cuda") or torch.get_autocast_dtype("cuda") == qkv.dtype)
            and sys.platform == "win32" and torch.__version__ == "2.8.0+cu128"
            and os.environ.get("DIRECT3D_V3_LEGACY_SDPA") != "1"
            and torch.cuda.get_device_capability(qkv.device) == (12, 0)):
        return _attention(*qkv.unbind(1))
    lengths_cpu = [b - a for a, b in zip(bounds[:-1], bounds[1:])]
    max_length = max(lengths_cpu)
    if max_length <= 0:
        return qkv.new_empty((0, qkv.shape[2], qkv.shape[3]))
    max_windows = max(1, min(128, 4096 // max_length))
    result = torch.empty((len(qkv), qkv.shape[2], qkv.shape[3]),
                         device=qkv.device, dtype=qkv.dtype)
    # A group containing one whole window has no padding or invalid keys.
    # Keep the same efficient SDPA engine while omitting its all-true mask.
    if (max_windows == 1 and all(length > 0 for length in lengths_cpu)
            and bounds[0] == 0 and bounds[-1] == len(qkv)
            and not args and not kwargs
            and qkv.is_cuda and qkv.is_contiguous() and qkv.shape[1:] == (3, 8, 96)
            and qkv.dtype == torch.float16
            and (not torch.is_autocast_enabled("cuda") or torch.get_autocast_dtype("cuda") == qkv.dtype)
            and sys.platform == "win32" and torch.__version__ == "2.8.0+cu128"
            and torch.cuda.get_device_capability(qkv.device) == (12, 0)
            and os.environ.get("DIRECT3D_V3_LEGACY_SDPA") != "1"
            and os.environ.get("DIRECT3D_V3_UNMASK_SINGLE_WINDOWS") == "1"):
        from torch.nn.attention import SDPBackend, sdpa_kernel

        with sdpa_kernel(SDPBackend.EFFICIENT_ATTENTION):
            for begin, end in zip(bounds[:-1], bounds[1:]):
                result[begin:end].copy_(_attention(*qkv[begin:end].unbind(1)))
        return result
    for start in range(0, len(lengths_cpu), max_windows):
        count = min(max_windows, len(lengths_cpu) - start)
        lens = torch.tensor(lengths_cpu[start:start + count], device=qkv.device, dtype=torch.long)
        begins = torch.tensor(bounds[start:start + count], device=qkv.device, dtype=torch.long)
        length = int(lens.max().item())
        offsets = torch.arange(length, device=qkv.device)
        valid = offsets[None, :] < lens[:, None]
        token_ids = begins[:, None] + offsets[None, :]
        token_ids = token_ids.clamp_max(len(qkv) - 1)
        packed = qkv[token_ids]  # [W, L, 3, H, D]
        q, k, v = packed.unbind(2)
        a, b, c = (t.permute(0, 2, 1, 3) for t in (q, k, v))
        # Key-only mask, with valid keys in every non-empty window.
        if _cudnn_fp16:
            _attention_counts["baseline"] += 1
        attention = F.scaled_dot_product_attention(
            a, b, c, attn_mask=valid[:, None, None, :], dropout_p=0.0
        )
        attention = attention.permute(0, 2, 1, 3).contiguous()
        result[token_ids[valid]] = attention[valid]
    return result


def flash_attn_varlen_kvpacked_func(q, kv, cu_seqlens_q, cu_seqlens_k, max_q, max_k, *args, **kwargs):
    import torch
    if not len(q):
        return torch.empty_like(q)
    query = _as_lengths(cu_seqlens_q)
    key = _as_lengths(cu_seqlens_k)
    if len(query) != len(key):
        raise ValueError("Mismatched batch offsets for ragged cross-attention")
    result = []
    for (ql, qr), (kl, kr) in zip(zip(query[:-1], query[1:]), zip(key[:-1], key[1:])):
        if qr > ql:
            k, v = kv[kl:kr].unbind(1)
            result.append(_attention(q[ql:qr], k, v))
    if len(result) == 1:
        return result[0]
    return torch.cat(result, dim=0) if result else torch.empty_like(q)


def install(*, cudnn_fp16=False):
    """Provide an API-compatible import only within the short-lived worker process."""
    global _cudnn_fp16
    _cudnn_fp16 = cudnn_fp16
    _cudnn_rejected.clear()
    attention_stats()
    m = types.ModuleType("flash_attn")
    # Transformers calls importlib.util.find_spec("flash_attn") while importing
    # DINOv3ViTModel. A synthetic module without __spec__ raises ValueError.
    # This spec makes detection safe while leaving the real flash-attn package
    # uninstalled, so Transformers uses the ordinary PyTorch attention path.
    m.__spec__ = ModuleSpec(name="flash_attn", loader=None)
    m.flash_attn_qkvpacked_func = flash_attn_qkvpacked_func
    m.flash_attn_varlen_qkvpacked_func = flash_attn_varlen_qkvpacked_func
    m.flash_attn_varlen_kvpacked_func = flash_attn_varlen_kvpacked_func
    sys.modules["flash_attn"] = m
