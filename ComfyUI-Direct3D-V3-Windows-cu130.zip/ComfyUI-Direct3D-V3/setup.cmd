@echo off
setlocal
cd /d "%~dp0"
where py.exe >nul 2>&1
if errorlevel 1 goto use_python
py -3.13 "%~dp0setup_windows.py" %*
goto finished
:use_python
python "%~dp0setup_windows.py" %*
:finished
set "setup_result=%errorlevel%"
if not "%setup_result%"=="0" echo Setup failed. Check the messages above and verify 64-bit Python 3.13 is installed.
exit /b %setup_result%
