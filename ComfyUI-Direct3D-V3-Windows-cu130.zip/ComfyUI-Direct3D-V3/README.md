# Direct3D-V3 Clean for ComfyUI on Windows

ComfyUI adapter made by [@MostAadTech](https://github.com/MostAadTech).

This archive targets NVIDIA GeForce RTX 20, 30, 40, and 50 series (SM 75, 86, 89, and 120). The worker uses **64-bit Python 3.13**, **PyTorch 2.12.1+cu130** and **torchvision 0.27.1+cu130**. Install the stated Python version and a current NVIDIA driver. ComfyUI may use its own Python and PyTorch.

## Setup

1. Extract the ComfyUI-Direct3D-V3 folder into ComfyUI/custom_nodes. Choose one archive and use a fresh folder when changing CUDA variants. Both archives register the same node IDs.
2. Request access to [DINOv3 ViT-H+](https://huggingface.co/facebook/dinov3-vith16plus-pretrain-lvd1689m). If prompted by setup, sign in with a Hugging Face read token from the account with access.
3. Run `setup.cmd` from the node folder. Setup creates .runtime and downloads the pinned PyTorch wheels, worker dependencies, DINOv3 weights and the 1536 geometry checkpoint. The voxelizer extensions are already compiled and bundled. Setup needs no CUDA Toolkit or Visual Studio.
4. Restart ComfyUI. Search for **Direct3D-V3 Clean | Refine (Mesh File, Low VRAM)**. Connect the mesh path and an image with matching foreground alpha or a foreground mask. Select **single_stage** for 1536-only setup.

Use `setup.cmd --stage all` to download 512, 1024 and 1536 for cascade mode. Add **--birefnet** to cache optional automatic background removal. With a matching foreground mask or cutout, BiRefNet is unnecessary. **--runtime-only** downloads the Python dependencies alone and **--models-only** downloads only the requested model files using the existing worker runtime.

## Geometry and attention

**Preserve scale** keeps the normalized mesh extent. **Shrink to fit** uses the existing 0.99 retry rule if occupancy exceeds the cap. The worker exports raw marching-cubes positions and triangles with decimation, hole filling and smoothing disabled.

Efficient attention is the default. The **cudnn_fp16** option uses PyTorch cuDNN for eligible FP16 calls and can change rounding and the raw surface.

## Build information

The binaries were built locally with the CUDA 13.5 Toolkit against PyTorch 2.12.1+cu130. This build has not been runtime-tested. Use a current NVIDIA driver with CUDA 13.5 support for the initial test.
The rebuilt extensions include GPU code for all four series. Setup and inference testing are pending for these ZIPs. Use FP16 on RTX 20 series.

The [upstream Direct3D-V3 project](https://github.com/DreamTechAI/Direct3D-V3) provides the base model and native voxelization code. See the included licenses and the individual model pages for terms.
