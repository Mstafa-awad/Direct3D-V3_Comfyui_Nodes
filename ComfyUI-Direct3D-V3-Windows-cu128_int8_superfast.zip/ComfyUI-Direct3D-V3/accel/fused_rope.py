"""Fused RoPE + RMSNorm + window-sorted staging for the split-window self-attention (head_dim 96, 16 heads).

Replaces, per Q/K projection, ~150 chunked PyTorch launches (fp32 complex rotate, fp16 round, fp32 RMSNorm,
fp16 round, scatter into the regular/shifted window buffers) with one Triton kernel that rounds at the same
points: rotated value -> fp16, then RMSNorm in fp32 on that fp16 value -> fp16.

Made by @MostAadTech (https://github.com/Mstafa-awad/Direct3D-V3_Comfyui_Nodes)
"""
import torch
import triton
import triton.language as tl


@triton.jit
def _rope_rms_stage(X, PH, W, REG, SHI, D0, D1, N, eps, slot,
                    SORTED: tl.constexpr, ROWS: tl.constexpr):
    pid = tl.program_id(0)
    h = tl.program_id(1)                      # 0..15
    r = pid * ROWS + tl.arange(0, ROWS)
    rm = r < N
    j = tl.arange(0, 64)                      # 48 complex pairs, padded to 64
    jm = j < 48
    m = rm[:, None] & jm[None, :]
    xbase = X + r[:, None].to(tl.int64) * (16 * 96) + h * 96
    re = tl.load(xbase + 2 * j[None, :], mask=m, other=0.0).to(tl.float32)
    im = tl.load(xbase + 2 * j[None, :] + 1, mask=m, other=0.0).to(tl.float32)
    pbase = PH + r[:, None].to(tl.int64) * 96
    c = tl.load(pbase + 2 * j[None, :], mask=m, other=1.0)
    s = tl.load(pbase + 2 * j[None, :] + 1, mask=m, other=0.0)
    out_re = (re * c - im * s).to(tl.float16).to(tl.float32)
    out_im = (re * s + im * c).to(tl.float16).to(tl.float32)
    ss = tl.sum(out_re * out_re + out_im * out_im, 1)
    rstd = 1.0 / tl.sqrt(ss / 96.0 + eps)
    w_re = tl.load(W + 2 * j, mask=jm, other=0.0).to(tl.float32)
    w_im = tl.load(W + 2 * j + 1, mask=jm, other=0.0).to(tl.float32)
    y_re = (out_re * rstd[:, None] * w_re[None, :]).to(tl.float16)
    y_im = (out_im * rstd[:, None] * w_im[None, :]).to(tl.float16)
    if h < 8:
        if SORTED:
            dst = tl.load(D0 + r, mask=rm, other=0).to(tl.int64)
        else:
            dst = r.to(tl.int64)
        obase = REG + dst[:, None] * (3 * 8 * 96) + slot * (8 * 96) + h * 96
    else:
        if SORTED:
            dst = tl.load(D1 + r, mask=rm, other=0).to(tl.int64)
        else:
            dst = r.to(tl.int64)
        obase = SHI + dst[:, None] * (3 * 8 * 96) + slot * (8 * 96) + (h - 8) * 96
    tl.store(obase + 2 * j[None, :], y_re, mask=m)
    tl.store(obase + 2 * j[None, :] + 1, y_im, mask=m)


def rope_rms_stage(projected, phases, norm, regular, shifted, slot, dst0=None, dst1=None):
    N = projected.shape[0]
    ph = torch.view_as_real(phases).reshape(N, 96)
    if not ph.is_contiguous():
        ph = ph.contiguous()
    rows = 32
    sorted_ = dst0 is not None
    _rope_rms_stage[(triton.cdiv(N, rows), 16)](projected, ph, norm.weight, regular, shifted,
                                                 dst0 if sorted_ else projected, dst1 if sorted_ else projected,
                                                 N, norm.eps, slot, SORTED=sorted_, ROWS=rows, num_warps=4)


def install():
    from direct3d.models import sparse_atten as sa

    def staged(self, x, index, window_size, window_cache):
        count = len(x)
        half = self.num_heads // 2
        phases = self.rope._get_phases(index[:, 1:].reshape(-1)).reshape(count, -1)
        regular = shifted = None
        for slot, (projection, norm) in enumerate(((self.to_q, self.q_norm), (self.to_k, self.k_norm), (self.to_v, None))):
            projected = projection(x).reshape(count, self.num_heads, self.head_dim)
            if slot == 0:
                regular = projected.new_empty((count, 3, half, self.head_dim))
                shifted = torch.empty_like(regular)
            if norm is not None:
                if not projected.is_contiguous():
                    projected = projected.contiguous()
                if self.sort_qkv:
                    rope_rms_stage(projected, phases, norm, regular, shifted, slot,
                                   window_cache[0][1], window_cache[1][1])
                else:
                    rope_rms_stage(projected, phases, norm, regular, shifted, slot)
            else:
                for begin in range(0, count, 1024):
                    part = slice(begin, begin + 1024)
                    value = projected[part]
                    if self.sort_qkv:
                        regular[window_cache[0][1][part], slot] = value[:, :half]
                        shifted[window_cache[1][1][part], slot] = value[:, half:]
                    else:
                        regular[part, slot].copy_(value[:, :half])
                        shifted[part, slot].copy_(value[:, half:])
            del projected
        head0 = sa.sparse_windowed_scaled_dot_product_self_attention(regular, window_size, window_cache[0], presorted=self.sort_qkv)
        del regular
        head1 = sa.sparse_windowed_scaled_dot_product_self_attention(shifted, window_size, window_cache[1], presorted=self.sort_qkv)
        del shifted
        combined = torch.cat((head0, head1), dim=1).reshape(count, -1)
        del head0, head1
        return self.out_proj(combined)

    sa.Attention._staged_forward = staged
