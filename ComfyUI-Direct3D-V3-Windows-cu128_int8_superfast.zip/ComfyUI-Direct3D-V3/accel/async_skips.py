"""SparseDiT.forward with host skips copied asynchronously through reused pinned buffers (bit-identical).

Made by @MostAadTech (https://github.com/Mstafa-awad/Direct3D-V3_Comfyui_Nodes)
"""
import os

import torch


def install():
    from direct3d.models import sparse_dit as sd
    from direct3d.models.sparse_atten import calc_window_partition

    def forward(self, x, index, layout, t, cond, *, return_camera=False, null_context=False):
        if return_camera:
            raise ValueError("async skips path does not support camera prediction")
        x, t = x.to(cond.dtype), t.to(cond.dtype)
        block_context = None if null_context else cond
        t = self.t_embedder(t * self.time_factor)
        s = self.x_embedder(x)
        c = t
        window0 = calc_window_partition(index, self.window_size, 0)
        window1 = calc_window_partition(index, self.window_size, self.shift_window)
        half = self.depth // 2
        compute = torch.cuda.current_stream()
        side = getattr(self, "_skip_stream", None)
        if side is None:
            side = self._skip_stream = torch.cuda.Stream()
        pool = getattr(self, "_skip_pool", None)
        if pool is None or pool[0].shape != s.shape:
            self._skip_pool = None
            need = half * s.numel() * s.element_size()
            pin = True
            try:
                import psutil
                # Pinned pages cannot be paged out. Only pin when RAM comfortably covers the pool (with
                # ComfyUI resident, free RAM reached ~0); otherwise use pageable buffers (same values).
                pin = psutil.virtual_memory().available > need + 4 * 2**30
            except ImportError:
                pass
            if os.environ.get("DIRECT3D_V3_PIN_SKIPS") in ("0", "1"):
                pin = os.environ["DIRECT3D_V3_PIN_SKIPS"] == "1"
            self._skip_pool = pool = [torch.empty(s.shape, dtype=s.dtype, pin_memory=pin) for _ in range(half)]
            print(f"INFO accel: host skips {need / 2**20:.0f} MiB {'pinned' if pin else 'pageable'}", flush=True)
        stored = [None] * half         # event marking each D2H completion
        fetched = {}                   # layer -> (gpu tensor, event)

        def prefetch(layer):
            slot = self.depth - 1 - layer      # skip slot consumed by `layer`
            if layer >= self.depth or slot < 0 or slot >= half:
                return
            dst = torch.empty(s.shape, dtype=s.dtype, device=s.device)
            with torch.cuda.stream(side):
                # `dst` comes from the compute stream's allocator pool and may reuse a block that queued
                # compute kernels still read. Wait for everything queued so far before overwriting it.
                # (Missing this corrupted skips at 512/1024, where small blocks are recycled at once.)
                side.wait_stream(compute)
                side.wait_event(stored[slot])
                dst.copy_(pool[slot], non_blocking=True)
                ev = torch.cuda.Event(); ev.record(side)
            fetched[layer] = (dst, ev)

        for layer, block in enumerate(self.blocks):
            if self.streamed_blocks is not None:
                block = self.streamed_blocks.bind(layer, block)
            skip_value = None
            if layer > half:
                skip_value, ev = fetched.pop(layer)
                compute.wait_event(ev)
            if layer >= half and layer + 1 < self.depth:
                prefetch(layer + 1)
            s = block(s, c, block_context, index, layout, skip_value=skip_value,
                      window_size=self.window_size, window_cache=(window0, window1))
            del skip_value
            if layer < half:
                ready = torch.cuda.Event(); ready.record(compute)
                with torch.cuda.stream(side):
                    side.wait_event(ready)
                    pool[layer].copy_(s, non_blocking=True)
                    ev = torch.cuda.Event(); ev.record(side)
                s.record_stream(side)
                stored[layer] = ev
        x = x.reshape(-1, self.patch_size**3, self.in_channels)
        x = self.decoder(x, s, index, window_cache=(window0, window1), window_size=self.window_size).squeeze(-1)
        return x.clamp(-1.0, 1.0)

    sd.SparseDiT.forward = forward
