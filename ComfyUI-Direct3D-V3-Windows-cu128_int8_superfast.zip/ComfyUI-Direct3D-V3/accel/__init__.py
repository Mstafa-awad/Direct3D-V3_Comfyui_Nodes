"""Triton acceleration for the Direct3D-V3 worker (SM80+; tuned on an RTX 5050 Laptop / SM120).

Modes
  off       original path (cuDNN/efficient SDPA, PyTorch ops)
  lossless  FP16 everywhere. Fused attention kernel with FP16 tensor-core accumulation per tile
            (more accurate than cuDNN on the 86k-token windows), fused pixel decoder, fused RoPE/RMSNorm
            staging, asynchronous pinned host skips. Output differences are at FP16 rounding level.
  fast      lossless + INT8 Q.K^T attention + SmoothQuant W8A8 INT8 for the least sensitive linears
            (self-attn QKV, cross-attn Q/out, decoder compact/attention projections).
  fastest   fast + INT8 MLP layers. Larger deviation (about BF16 level); opt-in.

Made by @MostAadTech (https://github.com/Mstafa-awad/Direct3D-V3_Comfyui_Nodes)
"""
import os
from pathlib import Path

import torch

MODES = ("lossless", "fast", "fastest", "off")
HERE = Path(__file__).resolve().parent

_GROUPS = {
    "qkv": lambda n: n.startswith("blocks.") and "attn1.to_" in n,
    "a2q": lambda n: n.startswith("blocks.") and "attn2.to_q" in n,
    "a2out": lambda n: n.startswith("blocks.") and "attn2.out_proj" in n,
    "fc1": lambda n: n.startswith("blocks.") and "mlp.fc1" in n,
    "fc2": lambda n: n.startswith("blocks.") and "mlp.fc2" in n,
    "dec_cmp": lambda n: n.startswith("decoder.res_blocks.") and "compact_" in n,
    "dec_attn": lambda n: n.startswith("decoder.res_blocks.") and ("attn1.to_" in n or "attn1.out_proj" in n),
}
_INT8_GROUPS = {
    "fast": ("qkv", "a2q", "a2out", "dec_cmp", "dec_attn"),
    "fastest": ("qkv", "a2q", "a2out", "dec_cmp", "dec_attn", "fc1", "fc2"),
}


def check(mode, device, dtype):
    """Return (effective_mode, reason). Falls back to 'off' when the kernels cannot run here."""
    if mode not in MODES:
        raise ValueError(f"Unknown accel mode {mode!r}; choose one of {MODES}")
    if mode == "off":
        return "off", "disabled by request"
    if os.environ.get("DIRECT3D_V3_ACCEL") == "0":
        return "off", "DIRECT3D_V3_ACCEL=0"
    if dtype != torch.float16:
        return "off", "Triton kernels need dtype fp16"
    if torch.cuda.get_device_capability(device) < (8, 0):
        return "off", "Triton kernels need an SM80+ GPU (RTX 30 series or newer)"
    try:
        import triton  # noqa: F401
    except Exception as error:  # pragma: no cover - depends on the runtime
        return "off", f"Triton unavailable ({type(error).__name__}: {error})"
    return mode, "ok"


def patch_runtime(mode):
    """Process-wide patches; call once after flash_sdpa_compat.install() and before sampling."""
    import flash_sdpa_compat as compat
    from . import async_skips, fused_rope, sage_triton

    qk = "fp16acc" if mode == "lossless" else "int8"
    original = compat._sdpa
    compat._attention_counts.setdefault("triton", 0)
    counts = compat._attention_counts

    def sdpa(q, k, v):
        if (q.is_cuda and q.dtype == k.dtype == v.dtype == torch.float16 and q.dim() == 4
                and q.shape[-1] == 96 and k.shape[-2] >= 1024 and k.shape[-2] == v.shape[-2]
                and q.stride(-1) == k.stride(-1) == v.stride(-1) == 1):
            B, H, N, D = q.shape
            # Write in [B, N, H, D] memory so the caller's permute(...).contiguous() is free.
            out = torch.empty((B, N, H, D), device=q.device, dtype=q.dtype).permute(0, 2, 1, 3)
            counts["triton"] += 1
            return sage_triton.attention(q, k, v, pv="fp16acc", qk=qk, out=out)
        return original(q, k, v)

    compat._sdpa = sdpa
    async_skips.install()
    fused_rope.install()


def _wanted(mode):
    names = _INT8_GROUPS[mode]
    return lambda name, lin=None: any(_GROUPS[g](name) for g in names)


def convert_int8(model, mode, log=print):
    """In-place SmoothQuant W8A8 conversion of the selected linears (1536 calibration)."""
    import gc
    from . import qlinear
    amax = torch.load(HERE / "smoothquant_amax_1536.pt") if model.depth == 17 else {}

    def make(name, lin):
        if name not in amax:
            return qlinear.Int8Linear(lin)
        a = amax[name].float().to(lin.weight.device).clamp_min(1e-5)
        w = lin.weight.detach().float().abs().amax(dim=0).clamp_min(1e-5)
        return qlinear.Int8Linear(lin, smooth=(a.sqrt() / w.sqrt()).clamp(1e-2, 1e2))

    count = qlinear.convert(model, make, _wanted(mode))
    gc.collect(); torch.cuda.empty_cache()
    log(f"INFO accel: {count} linears converted to SmoothQuant W8A8 INT8 ({', '.join(_INT8_GROUPS[mode])})")
    return count


def int8_checkpoint_path(folder, mode):
    return Path(folder) / f"model_int8_{mode}.safetensors"


def save_int8_checkpoint(model, path, mode):
    from safetensors.torch import save_file
    state = {k: v.detach().contiguous().cpu() for k, v in model.state_dict().items()}
    save_file(state, str(path), metadata={"format": "direct3d-v3-int8", "mode": mode, "version": "1",
                                          "groups": ",".join(_INT8_GROUPS[mode])})
    return sum(v.numel() * v.element_size() for v in state.values())


def load_int8_checkpoint(path, config, device, mode):
    """Build SparseDiT with Int8Linear shells and assign the saved INT8/FP16 tensors directly on `device`."""
    from inspect import signature
    from safetensors import safe_open
    from torch import nn
    from direct3d.models.sparse_dit import SparseDiT
    from . import qlinear
    backend = {"backend": "pread"} if "backend" in signature(safe_open).parameters else {}
    with safe_open(str(path), framework="pt", device="cpu", **backend) as archive:
        meta = archive.metadata() or {}
        if meta.get("format") != "direct3d-v3-int8" or meta.get("mode") != mode:
            raise ValueError(f"{path} is not a {mode} Direct3D-V3 INT8 checkpoint ({meta})")
        names = set(archive.keys())
        with torch.device("meta"):
            model = SparseDiT(**config)
        wanted = _wanted(mode)
        for name, child in list(model.named_modules()):
            for attr, sub in list(child.named_children()):
                full = f"{name}.{attr}" if name else attr
                if isinstance(sub, nn.Linear) and wanted(full):
                    setattr(child, attr, qlinear.Int8Linear.shell(
                        sub.in_features, sub.out_features, sub.bias is not None, f"{full}.inv_smooth" in names))
        keys = model.state_dict().keys()
        if set(keys) != names:
            raise ValueError(f"{path} does not match the model layout ({len(set(keys) ^ names)} keys differ)")
        tensors = {k: archive.get_tensor(k).to(device) for k in keys}
    model.load_state_dict(tensors, assign=True, strict=True)
    model.streamed_blocks = None
    return model.eval()


def prepare_model(model, mode, device, *, stream, log=print, prequantized=False):
    """Per-model transforms. For INT8 modes the model must be resident (loaded with stream_blocks=False)."""
    import gc
    from . import fused_decoder
    if mode in _INT8_GROUPS:
        if not prequantized:
            convert_int8(model, mode, log)
        if stream:
            from . import stream_bytes
            weights = stream_bytes.stream_model_blocks(model, device)
            log(f"INFO accel: block streaming {weights.host_bytes / 2**20:.0f} MiB "
                f"{'pinned' if weights.pinned else 'pageable'} host RAM, "
                f"{weights.staging_bytes / 2**20:.0f} MiB GPU staging")
    fused_decoder.install(model)
    gc.collect(); torch.cuda.empty_cache()
    return model


def load_dino(folder, dtype, device):
    """Build DINOv3 directly on the GPU in `dtype` and stream the checkpoint tensor by tensor.

    The transformers loader materialises the full FP32 checkpoint (3.4 GB) in CPU RAM before casting;
    on 16 GB machines that drove free RAM to ~0. The per-tensor cast here is the same FP32->FP16 rounding.
    """
    from safetensors import safe_open
    from torch import nn
    from torchvision.transforms import Normalize
    from transformers import DINOv3ViTConfig, DINOv3ViTModel
    from direct3d.models.image_encoder import DINOv3FeatureExtractor

    folder = Path(folder)
    config = DINOv3ViTConfig.from_pretrained(str(folder))
    from inspect import signature
    from transformers.modeling_utils import no_init_weights
    with torch.device(device), no_init_weights():
        backbone = DINOv3ViTModel._from_config(config, dtype=dtype)
    state = backbone.state_dict()
    backend = {"backend": "pread"} if "backend" in signature(safe_open).parameters else {}
    with safe_open(str(folder / "model.safetensors"), framework="pt", device="cpu", **backend) as archive:
        names = set(archive.keys())
        missing = [k for k in state if k not in names and not k.endswith("inv_freq")]
        if missing:
            raise KeyError(f"DINOv3 checkpoint lacks {len(missing)} tensors, e.g. {missing[:3]}")
        with torch.no_grad():
            for key, target in state.items():
                if key in names:
                    target.copy_(archive.get_tensor(key).to(device=device).to(target.dtype))
    extractor = DINOv3FeatureExtractor.__new__(DINOv3FeatureExtractor)
    nn.Module.__init__(extractor)
    extractor.backbone = backbone
    extractor.normalize = Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225))
    extractor.eval()
    return extractor
