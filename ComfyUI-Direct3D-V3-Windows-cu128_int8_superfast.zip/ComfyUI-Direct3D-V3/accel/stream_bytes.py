"""Stream per-block weights of any dtypes (int8 weights, fp32 scales, fp16 biases) from pinned host memory.

Each block's parameters and buffers are packed into one byte buffer on the host. Two GPU staging buffers
alternate between blocks; block i+1 is copied on a side stream while block i computes.  Values are copied
bit-for-bit, so results equal the resident model.

Made by @MostAadTech (https://github.com/Mstafa-awad/Direct3D-V3_Comfyui_Nodes)
"""
import torch
from torch.func import functional_call

ALIGN = 256


def _should_pin(nbytes):
    """Pin (page-lock) the host copy only when RAM is plentiful.

    Windows shows pinned RAM as "Shared GPU memory"; it is system RAM the GPU copies from, not VRAM. Pinning
    makes the per-block copy faster, but pinned pages cannot be paged out, so on a busy 16 GB machine ordinary
    pageable RAM is used instead (identical values, slightly slower copies).
    """
    import os
    override = os.environ.get("DIRECT3D_V3_PIN_WEIGHTS")
    if override in ("0", "1"):
        return override == "1"
    try:
        import psutil
        return psutil.virtual_memory().available > nbytes + 6 * 2**30
    except ImportError:
        return False


class StreamedBlocksBytes:
    def __init__(self, blocks, device, pin=None):
        self.layouts = []
        self.host = []
        if pin is None:
            pin = _should_pin(sum(t.numel() * t.element_size() for b in blocks
                                  for _, t in list(b.named_parameters()) + list(b.named_buffers())))
        self.pinned = pin
        for block in blocks:
            layout = {}
            size = 0
            tensors = list(block.named_parameters()) + list(block.named_buffers())
            for name, t in tensors:
                start = (size + ALIGN - 1) // ALIGN * ALIGN
                nbytes = t.numel() * t.element_size()
                layout[name] = (start, nbytes, t.dtype, tuple(t.shape))
                size = start + nbytes
            host = torch.empty(max(size, 1), dtype=torch.uint8, pin_memory=pin)
            for name, t in tensors:
                start, nbytes, dtype, shape = layout[name]
                if nbytes:
                    host[start:start + nbytes].copy_(t.detach().contiguous().view(-1).view(torch.uint8).cpu())
            self.layouts.append(layout)
            self.host.append(host)
        self.capacity = max(h.numel() for h in self.host)
        self.staging = [torch.empty(self.capacity, dtype=torch.uint8, device=device) for _ in range(2)]
        self.views = [[self._views(i, buf) for buf in self.staging] for i in range(len(blocks))]
        self.copy_stream = torch.cuda.Stream(device=device)
        self.copied = [None] * len(blocks)
        self.host_bytes = sum(h.numel() for h in self.host)
        self.staging_bytes = 2 * self.capacity

    def _views(self, layer, buf):
        out = {}
        for name, (start, nbytes, dtype, shape) in self.layouts[layer].items():
            out[name] = buf[start:start + nbytes].view(dtype).view(shape)
        return out

    def _prefetch(self, layer, after):
        if layer >= len(self.host):
            return
        buf = self.staging[layer % 2]
        with torch.cuda.stream(self.copy_stream):
            if after is not None:
                self.copy_stream.wait_event(after)
            n = self.host[layer].numel()
            buf[:n].copy_(self.host[layer], non_blocking=True)
            event = torch.cuda.Event()
            event.record(self.copy_stream)
        self.copied[layer] = event

    def bind(self, layer, block):
        if torch.is_grad_enabled() or block.training:
            raise RuntimeError("Streamed blocks support inference only.")
        compute = torch.cuda.current_stream()
        if layer == 0 or self.copied[layer] is None:
            self._prefetch(layer, None)
        compute.wait_event(self.copied[layer])
        # Everything queued so far on the compute stream (through block layer-1) is done with the other
        # staging buffer once this event fires; then block layer+1 may overwrite it.
        free = torch.cuda.Event()
        free.record(compute)
        self._prefetch(layer + 1, free)
        params = self.views[layer][layer % 2]

        def run(*args, **kwargs):
            return functional_call(block, params, args, kwargs, strict=True)
        return run


def stream_model_blocks(model, device):
    """Move a resident model's blocks to pinned host storage and enable streaming; frees their GPU memory."""
    import gc
    weights = StreamedBlocksBytes(model.blocks, device)
    for block in model.blocks:
        block.to("meta")
    model.streamed_blocks = weights
    gc.collect()
    torch.cuda.empty_cache()
    return weights
