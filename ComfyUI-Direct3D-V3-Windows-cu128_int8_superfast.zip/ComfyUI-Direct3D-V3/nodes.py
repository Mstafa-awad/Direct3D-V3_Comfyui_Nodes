"""ComfyUI nodes; no Direct3D / model imports in this file."""
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXTENSIONS = {".obj", ".glb", ".ply"}


class AnyMesh(str):
    """Allow connected meshes from differing ComfyUI 3D packs."""
    def __ne__(self, other):
        return False

    def __eq__(self, other):
        return True


ANY_MESH = AnyMesh("*")


def _folder_paths():
    import folder_paths
    return folder_paths


def _input_mesh_files():
    base = Path(_folder_paths().get_input_directory())
    names = []
    if base.is_dir():
        for dirpath, subdirs, files in os.walk(base):
            subdirs[:] = [d for d in subdirs if not d.startswith(".")]
            for file in files:
                if Path(file).suffix.lower() in EXTENSIONS:
                    names.append(str((Path(dirpath) / file).relative_to(base)).replace("\\", "/"))
                if len(names) > 2000:
                    break
            if len(names) > 2000:
                break
    return sorted(names) or ["[Place an OBJ/GLB/PLY in ComfyUI/input first]"]


def _safe_file_path(path):
    if not isinstance(path, (str, os.PathLike)):
        raise ValueError("Expected a path to an OBJ/GLB/PLY file")
    value = str(path).strip().strip('"')
    candidate = Path(value).expanduser()
    if not candidate.is_absolute():
        candidate = Path(_folder_paths().get_input_directory()) / candidate
    candidate = candidate.resolve()
    if candidate.suffix.lower() not in EXTENSIONS:
        raise ValueError(f"Unsupported coarse mesh extension: {candidate.suffix}. Use OBJ, GLB or PLY.")
    if not candidate.is_file():
        raise FileNotFoundError(f"Cannot find coarse mesh: {candidate}")
    return candidate


def _numpy(t):
    if hasattr(t, "detach"):
        t = t.detach()
    if hasattr(t, "cpu"):
        t = t.cpu()
    if hasattr(t, "numpy"):
        return t.numpy()
    import numpy as np
    return np.asarray(t)


def _convert_mesh(source, path):
    """Serialize a connected Trimesh, Scene, basic vertex/face object or mesh path."""
    if isinstance(source, (str, os.PathLike)):
        return _safe_file_path(source)
    import trimesh
    if isinstance(source, trimesh.Scene):
        source = source.dump(concatenate=True)
    if isinstance(source, trimesh.Trimesh):
        source.export(str(path))
        return path
    if isinstance(source, dict):
        if "mesh" in source:
            return _convert_mesh(source["mesh"], path)
        v = source.get("vertices", source.get("verts"))
        f = source.get("faces", source.get("triangles"))
    elif isinstance(source, (tuple, list)) and len(source) == 2:
        v, f = source
    else:
        v = getattr(source, "vertices", getattr(source, "verts", None))
        f = getattr(source, "faces", getattr(source, "triangles", None))
    if v is None or f is None:
        raise TypeError(
            f"Unsupported mesh object ({type(source).__name__}); supply Trimesh, Scene, "
            "vertices/faces, or connect the 'Direct3D Mesh File' node instead."
        )
    mesh = trimesh.Trimesh(vertices=_numpy(v), faces=_numpy(f), process=False)
    if len(mesh.vertices) == 0 or len(mesh.faces) == 0:
        raise ValueError("Input mesh is empty")
    mesh.export(str(path))
    return path


def _write_image(image, path, mask=None):
    import numpy as np
    from PIL import Image
    import torch
    import torch.nn.functional as F
    if image.ndim != 4 or image.shape[0] < 1:
        raise ValueError("IMAGE expected in ComfyUI [B,H,W,C] format")
    arr = (_numpy(image[0]).clip(0, 1) * 255).round().astype("uint8")
    if arr.shape[-1] < 3:
        arr = np.repeat(arr[..., :1], 3, axis=-1)
    if arr.shape[-1] > 4:
        arr = arr[..., :4]
    if mask is not None:
        # Comfy masks are normally 0=background, 1=foreground.
        m = mask[0] if mask.ndim == 3 else mask
        m = m.detach().float().cpu().unsqueeze(0).unsqueeze(0)
        if m.shape[-2:] != arr.shape[:2]:
            m = F.interpolate(m, size=arr.shape[:2], mode="bilinear", align_corners=False)
        alpha = (m[0, 0].clamp(0, 1).numpy() * 255).round().astype("uint8")
        arr = np.concatenate([arr[..., :3], alpha[..., None]], axis=-1)
    Image.fromarray(arr).save(str(path))
    return mask is not None or arr.shape[2] == 4


def _python():
    p = ROOT / ".runtime" / "Scripts" / "python.exe"
    if not p.is_file():
        raise RuntimeError(
            "Direct3D-V3 runtime is not installed. Run setup.cmd from the node folder "
            "and restart ComfyUI."
        )
    return p


def _clean_prefix(prefix):
    name = re.sub(r"[^A-Za-z0-9_.-]", "_", str(prefix).strip())[:72]
    name = name.strip("._-")
    return name or "Direct3D"


def _unload_comfy():
    try:
        import comfy.model_management as mm
        mm.unload_all_models()
        if hasattr(mm, "soft_empty_cache"):
            mm.soft_empty_cache()
    except Exception as exc:
        print(f"[Direct3D-V3] Could not fully unload Comfy models: {exc}")
    try:
        import torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except Exception:
        pass


def _launch(image, coarse_mesh, *, resolution, steps, guidance, max_tokens, token_fit,
            seed, model, dtype, offline, use_alpha, output_prefix, file_format, stage_mode, mask=None,
            attention_backend="efficient", accel_mode="lossless"):
    import folder_paths
    output_dir = Path(folder_paths.get_output_directory()) / "Direct3D-V3"
    output_dir.mkdir(parents=True, exist_ok=True)
    # Unique prefix even if user queues the same node repeatedly.
    import uuid
    output_path = output_dir / f"{_clean_prefix(output_prefix)}_{uuid.uuid4().hex[:8]}.{file_format}"
    temp_base = Path(folder_paths.get_temp_directory())
    temp_base.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="direct3d_", dir=str(temp_base)) as tdir:
        temp = Path(tdir)
        image_path = temp / "reference.png"
        existing_alpha = _write_image(image, image_path, mask=mask)
        mesh_path = _convert_mesh(coarse_mesh, temp / "coarse.glb")
        cfg = {
            "image": str(image_path), "coarse_mesh": str(mesh_path), "output": str(output_path),
            "resolution": int(resolution), "steps": int(steps), "guidance": float(guidance),
            "max_tokens": int(max_tokens), "token_fit": token_fit,
            "seed": int(seed), "model": model.strip() or "wushuang98/Direct3D-V3",
            "dtype": dtype, "offline": bool(offline), "use_alpha": bool(use_alpha and existing_alpha),
            "stage_mode": stage_mode, "attention_backend": attention_backend, "accel_mode": accel_mode,
        }
        config_path = temp / "run.json"
        config_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
        _unload_comfy()
        env = os.environ.copy()
        env.update({"PYTHONUTF8": "1", "PYTHONUNBUFFERED": "1", "HF_HUB_DISABLE_SYMLINKS_WARNING": "1"})
        # ComfyUI can select cudaMallocAsync in its own process. Use the
        # measured native allocator in this separate worker.
        env["PYTORCH_CUDA_ALLOC_CONF"] = "backend:native"
        env["PYTORCH_ALLOC_CONF"] = "backend:native"
        worker = ROOT / "worker.py"
        command = [str(_python()), "-u", str(worker), "--config", str(config_path)]
        history = []
        total = (1 if stage_mode == "single_stage" else (1 if resolution == 512 else 2 if resolution == 1024 else 3)) * steps
        try:
            from comfy.utils import ProgressBar
            bar = ProgressBar(total)
        except Exception:
            bar = None
        completed = 0
        print(f"[Direct3D-V3] Starting {resolution} on low-VRAM worker. Output: {output_path}")
        # stderr merged; stdout line-buffered; no shell or arbitrary commands.
        proc = subprocess.Popen(command, cwd=str(ROOT), env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace",
                                bufsize=1, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        try:
            for line in proc.stdout:
                s = line.rstrip()
                history.append(s)
                if len(history) > 350:
                    history.pop(0)
                console_encoding = getattr(sys.stdout, "encoding", None) or "utf-8"
                printable = s.encode(console_encoding, errors="backslashreplace").decode(console_encoding)
                print("[Direct3D-V3] " + printable)
                if s.startswith("PROGRESS ") and bar is not None:
                    parts = s.split()
                    if len(parts) >= 4:
                        # Upstream can issue step zero; only count monotonically increasing work.
                        done = min(int(parts[2]), steps)
                        idx = (int(parts[1]) // 512) - 1
                        # 512 => index 0; 1024 => 1; 1536 => 2
                        wanted = (0 if stage_mode == "single_stage" else idx * steps) + done
                        if wanted > completed:
                            bar.update(wanted - completed)
                            completed = wanted
            code = proc.wait()
        finally:
            if proc.poll() is None:
                proc.kill()
                proc.wait()
            proc.stdout.close()
        if code != 0 or not output_path.is_file():
            if output_path.exists():
                output_path.unlink()
            tail = "\n".join(history[-30:])
            raise RuntimeError(f"Direct3D-V3 Clean worker failed (exit code {code}).\n{tail}")
        info = f"Exported {output_path.name} at stage {resolution}; see Comfy console for logs."
        return (str(output_path), str(output_path), info)


class Direct3DMeshFile:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"mesh_file": (_input_mesh_files(),)}}

    RETURN_TYPES = ("MESH_PATH",)
    RETURN_NAMES = ("coarse_mesh_path",)
    FUNCTION = "get_file"
    CATEGORY = "Direct3D-V3"
    DESCRIPTION = "Made by @MostAadTech"

    def get_file(self, mesh_file):
        return (str(_safe_file_path(mesh_file)),)


class Direct3DMeshPath:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"absolute_or_input_relative_path": ("STRING", {"default": "", "multiline": False})}}

    RETURN_TYPES = ("MESH_PATH",)
    RETURN_NAMES = ("coarse_mesh_path",)
    FUNCTION = "get_file"
    CATEGORY = "Direct3D-V3"
    DESCRIPTION = "Made by @MostAadTech"

    def get_file(self, absolute_or_input_relative_path):
        return (str(_safe_file_path(absolute_or_input_relative_path)),)


class _BaseRefine:
    RETURN_TYPES = ("MESH_PATH", "STRING", "STRING")
    RETURN_NAMES = ("mesh_path", "mesh_path_text", "info")
    FUNCTION = "refine"
    CATEGORY = "Direct3D-V3"
    DESCRIPTION = "Made by @MostAadTech"
    OUTPUT_NODE = True

    @staticmethod
    def _optional_settings():
        return {
            "foreground_mask": ("MASK",),
            "attention_backend": (["efficient", "cudnn_fp16"], {
                "default": "efficient",
                "tooltip": "Used only when accel_mode is off. Experimental cuDNN for large FP16 attention calls.",
            }),
            "accel_mode": (["lossless", "fast", "fastest", "off"], {
                "default": "lossless",
                "tooltip": "Triton kernels for FP16 dtype. lossless: same quality as FP16 (rounding-level differences), "
                           "~1.6x faster sampling. fast: adds INT8 attention scores and SmoothQuant INT8 for the "
                           "least sensitive layers, ~2.1x, small deviation. fastest: also INT8 MLP, ~2.3x, deviation "
                           "near BF16 level. off: original path. Acceleration made by @MostAadTech.",
            }),
        }

    @staticmethod
    def _settings():
        return {
            "image": ("IMAGE",),
            "resolution": ([512, 1024, 1536], {"default": 1536}),
            "steps": ("INT", {"default": 8, "min": 1, "max": 100}),
            "guidance": ("FLOAT", {"default": 4.0, "min": 0.0, "max": 20.0, "step": 0.25}),
            "max_tokens": ("INT", {"default": 50000, "min": 1000, "max": 170000, "step": 1000}),
            "token_fit": (["shrink_to_fit", "preserve_scale"], {"default": "preserve_scale",
                            "tooltip": "Preserve scale refuses a mesh above the cap. Shrink to fit can reduce geometric detail."}),
            "seed": ("INT", {"default": 2026, "min": 0, "max": 2**63 - 1}),
            "model": ("STRING", {"default": "wushuang98/Direct3D-V3"}),
            "dtype": (["fp16", "bf16"], {"default": "fp16"}),
            "offline": ("BOOLEAN", {"default": True}),
            "use_alpha": ("BOOLEAN", {"default": True}),
            "output_prefix": ("STRING", {"default": "Direct3D_refined"}),
            "file_format": (["glb", "obj", "ply"], {"default": "glb"}),
            "stage_mode": (["cascade", "single_stage"], {"default": "single_stage"}),
        }


class Direct3DRefineFile(_BaseRefine):
    """Takes input image + mesh file (from File, Path or other mesh file nodes)."""
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"coarse_mesh_path": ("MESH_PATH",), **cls._settings()},
                "optional": cls._optional_settings()}

    def refine(self, coarse_mesh_path, image, resolution, steps, guidance, max_tokens,
               token_fit, seed, model, dtype, offline, use_alpha, output_prefix,
               file_format, stage_mode, foreground_mask=None, attention_backend="efficient",
               accel_mode="lossless"):
        return _launch(image, _safe_file_path(coarse_mesh_path), resolution=resolution,
                       steps=steps, guidance=guidance, max_tokens=max_tokens,
                       token_fit=token_fit, seed=seed, model=model, dtype=dtype,
                       offline=offline, use_alpha=use_alpha, output_prefix=output_prefix,
                       file_format=file_format, stage_mode=stage_mode, mask=foreground_mask,
                       attention_backend=attention_backend, accel_mode=accel_mode)


class Direct3DRefineConnected(_BaseRefine):
    """Accepts a connected Trimesh/Scene/vertices+faces object from another pack."""
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"coarse_mesh": (ANY_MESH,), **cls._settings()},
                "optional": cls._optional_settings()}

    def refine(self, coarse_mesh, image, resolution, steps, guidance, max_tokens,
               token_fit, seed, model, dtype, offline, use_alpha, output_prefix,
               file_format, stage_mode, foreground_mask=None, attention_backend="efficient",
               accel_mode="lossless"):
        return _launch(image, coarse_mesh, resolution=resolution,
                       steps=steps, guidance=guidance, max_tokens=max_tokens,
                       token_fit=token_fit, seed=seed, model=model, dtype=dtype,
                       offline=offline, use_alpha=use_alpha, output_prefix=output_prefix,
                       file_format=file_format, stage_mode=stage_mode, mask=foreground_mask,
                       attention_backend=attention_backend, accel_mode=accel_mode)


NODE_CLASS_MAPPINGS = {
    "Direct3DMeshFileClean": Direct3DMeshFile,
    "Direct3DMeshPathClean": Direct3DMeshPath,
    "Direct3DRefineFileClean": Direct3DRefineFile,
    "Direct3DRefineConnectedClean": Direct3DRefineConnected,
}
NODE_DISPLAY_NAME_MAPPINGS = {
    "Direct3DMeshFileClean": "Direct3D-V3 Clean | Choose Coarse Mesh File (Made by @MostAadTech)",
    "Direct3DMeshPathClean": "Direct3D-V3 Clean | Mesh File Path (Made by @MostAadTech)",
    "Direct3DRefineFileClean": "Direct3D-V3 Clean | Refine (Mesh File, Low VRAM) (Made by @MostAadTech)",
    "Direct3DRefineConnectedClean": "Direct3D-V3 Clean | Refine (Connected Mesh, Low VRAM) (Made by @MostAadTech)",
}
