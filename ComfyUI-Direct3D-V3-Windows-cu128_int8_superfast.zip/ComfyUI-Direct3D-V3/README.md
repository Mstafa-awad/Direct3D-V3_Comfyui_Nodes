# Direct3D-V3 Clean SuperFast for ComfyUI (Windows, cu128)

Made by @MostAadTech (https://github.com/Mstafa-awad/Direct3D-V3_Comfyui_Nodes)

ComfyUI custom nodes that refine a coarse mesh with Direct3D-V3 and a reference image, exporting raw
marching-cubes geometry. This SuperFast build adds Triton kernels by @MostAadTech (`accel_mode`).

Worker: Python 3.12 x64, PyTorch 2.8.0+cu128. Prebuilt voxelizers for GeForce RTX 20/30/40/50.
Acceleration needs RTX 30 series or newer (SM80+); older GPUs fall back to the original path automatically.

## Install

1. Extract the `ComfyUI-Direct3D-V3` folder into `ComfyUI/custom_nodes` (replace any previous Direct3D-V3 build).
2. Request access to DINOv3 ViT-H+ on Hugging Face (facebook/dinov3-vith16plus-pretrain-lvd1689m).
3. Run `setup.cmd` in the node folder. It creates `.runtime` with PyTorch, Triton and the dependencies and
   downloads DINOv3 and the 1536 checkpoint. For cascade: `setup.cmd --models-only --stage all`.
4. Restart ComfyUI.

## accel_mode

| mode | what it does |
| --- | --- |
| `lossless` (default) | Fused FP16 attention, decoder and RoPE kernels, async transfers. Same quality as FP16 (rounding-level differences). |
| `fast` | + INT8 attention scores and SmoothQuant INT8 for the least sensitive layers (1536 stage). Small deviation. |
| `fastest` | + INT8 MLP layers. Slightly larger deviation. |
| `off` | Original path. |

Measured on an RTX 5050 Laptop (8 GB), 1536 single stage, 152,121 patches, 8 steps (cu128 build):
sampling 925 s (off), 576 s (lossless, 1.61x), 459 s (fast, 2.02x), 425 s (fastest, 2.18x).
Also: DINOv3 loads straight to the GPU (peak RAM 5.3 GB -> 0.8 GB) and marching cubes reserves 6.4 GB instead
of 10.5 GB VRAM at 152k patches. Environment switches: `DIRECT3D_V3_ACCEL=0` (disable),
`DIRECT3D_V3_PIN_WEIGHTS=0` / `DIRECT3D_V3_PIN_SKIPS=0` (never page-lock RAM).

Built on Direct3D-V3 (DreamTechAI), its geometry checkpoints (wushuang98/Direct3D-V3) and DINOv3. Licenses are
included; model weights are downloaded separately under their own terms.
