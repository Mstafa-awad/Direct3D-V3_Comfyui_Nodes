
__global__ void unpack(const unsigned* words, bool* occupied, int64_t count) {
    int64_t id = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (id < count) occupied[id] = (words[id >> 5] >> (id & 31)) & 1u;
}

void launch_patches(float* vertices, int* faces, unsigned* words, bool* occupied,
                    int triangles, int dim, int patch, float margin, int64_t count) {
    auto stream = at::cuda::getCurrentCUDAStream();
    if (triangles) {
        compute_sdf_kernel<<<(triangles + 255) / 256, 256, 0, stream>>>(vertices, faces, words, patch, triangles, dim, margin);
        C10_CUDA_KERNEL_LAUNCH_CHECK();
    }
    unpack<<<(count + 255) / 256, 256, 0, stream>>>(words, occupied, count);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
}
