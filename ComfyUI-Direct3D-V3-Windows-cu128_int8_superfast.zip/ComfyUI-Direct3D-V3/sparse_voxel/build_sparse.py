import hashlib
from contextlib import chdir
from pathlib import Path
import tempfile

from setuptools import setup
from torch.utils.cpp_extension import BuildExtension, CUDAExtension


def build():
    here = Path(__file__).resolve().parent
    vendor = here.parent / 'vendor' / 'Direct3D-V3'
    legacy = (vendor / 'third_party/voxelization/src/voxel_kernel.cu').read_text(encoding='utf8')
    if hashlib.sha256(legacy.encode()).hexdigest() != '6a7ba416ef4149c19058a71d88aa339a1088a4372af93227fb0dbcf1f7d7307b':
        raise RuntimeError('Legacy SAT source changed; review before rebuilding the candidate.')
    kernel = legacy.split('void compute_valid_sdf_cuda(')[0]
    kernel = kernel.replace('bool* voxel, const int DIM', 'unsigned* words, int patch, const int DIM')
    kernel = kernel.replace('bool * voxel, int numTriangles', 'unsigned* words, int patch, int numTriangles')
    kernel = kernel.replace('triangle, voxel, DIM', 'triangle, words, patch, DIM')
    start = kernel.index('uint32_t idx =')
    end = kernel.index('voxel[idx]=insect;', start) + len('voxel[idx]=insect;')
    kernel = kernel[:start] + 'mark_patches(words, patch, DIM, i, j, k);' + kernel[end:]
    with tempfile.TemporaryDirectory(prefix='d3patch-') as temp:
        generated = Path(temp) / 'patch_kernel.cu'
        generated.write_text((here / 'mark.cuh').read_text() + '\n' + kernel + (here / 'launch.cuh').read_text(), encoding='utf8')
        name = '_d3patch_sm120'
        with chdir(temp):
            setup(name=name, ext_modules=[CUDAExtension(name, [str(generated), str(here / 'binding.cpp')])],
                  cmdclass={'build_ext': BuildExtension}, script_args=['build_ext', '--build-lib', str(vendor / 'direct3d/utils')])


if __name__ == '__main__':
    build()
