__device__ void mark_patches(unsigned* words, int patch, int dim, int cell_x, int cell_y, int cell_z) {
    const int grid = dim / patch;
    const int high_x = min(cell_x + 1, dim - 1) / patch;
    const int high_y = min(cell_y + 1, dim - 1) / patch;
    const int high_z = min(cell_z + 1, dim - 1) / patch;
    for (int px = cell_x / patch; px <= high_x; ++px)
        for (int py = cell_y / patch; py <= high_y; ++py)
            for (int pz = cell_z / patch; pz <= high_z; ++pz) {
                auto id = (static_cast<unsigned long long>(px) * grid + py) * grid + pz;
                atomicOr(words + (id >> 5), 1u << (id & 31));
            }
}
