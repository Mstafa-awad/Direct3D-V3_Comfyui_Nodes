#include <torch/extension.h>
#include <c10/cuda/CUDAGuard.h>
#include <climits>

void launch_patches(float*, int*, unsigned*, bool*, int, int, int, float, int64_t);

torch::Tensor occupied(torch::Tensor vertices, torch::Tensor faces, int dim, int patch, float margin) {
    TORCH_CHECK(vertices.is_cuda() && vertices.device() == faces.device(), "Expected one CUDA device");
    TORCH_CHECK(vertices.is_contiguous() && faces.is_contiguous(), "Expected contiguous inputs");
    TORCH_CHECK(vertices.dim() == 2 && vertices.size(1) == 3 && faces.dim() == 2 && faces.size(1) == 3,
                "Expected vertices and faces with three columns");
    TORCH_CHECK(vertices.numel() <= INT_MAX && faces.numel() <= INT_MAX, "Mesh exceeds native index range");
    TORCH_CHECK(dim > 1 && dim <= 1536 && patch > 0 && dim % patch == 0, "Unsupported grid shape");
    c10::cuda::CUDAGuard guard(vertices.device());
    int64_t grid = dim / patch, count = grid * grid * grid;
    auto words = torch::zeros({(count + 31) / 32}, vertices.options().dtype(torch::kInt32));
    auto mask = torch::empty({grid, grid, grid}, vertices.options().dtype(torch::kBool));
    launch_patches(vertices.data_ptr<float>(), faces.data_ptr<int>(), reinterpret_cast<unsigned*>(words.data_ptr<int>()),
                   mask.data_ptr<bool>(), faces.size(0), dim, patch, margin, count);
    return mask;
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, module) {
    module.def("occupied", &occupied);
}
