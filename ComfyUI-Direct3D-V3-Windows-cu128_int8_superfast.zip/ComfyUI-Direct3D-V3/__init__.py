"""Windows / CUDA 12.8 ComfyUI adapter for DreamTechAI Direct3D-V3.

This wrapper intentionally imports no upstream ML libraries at startup.
Inference is performed in a separate Python 3.12 environment.
"""
from .nodes import NODE_CLASS_MAPPINGS, NODE_DISPLAY_NAME_MAPPINGS

__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS"]
