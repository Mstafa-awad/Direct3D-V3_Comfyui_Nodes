# Direct3D-V3 Clean SuperFast + Multiview for ComfyUI (Windows, cu128)

Made by @MostAadTech (https://github.com/Mstafa-awad/Direct3D-V3_Comfyui_Nodes)

ComfyUI custom nodes that refine a coarse mesh with Direct3D-V3 and reference images, exporting raw marching-cubes
geometry. This build contains:

* the single-view Refine nodes with SuperFast Triton kernels (`accel_mode`);
* the new **Refine Multiview** node: front image plus optional back / left / right / top / bottom views.

Worker: Python 3.12 x64, PyTorch 2.8.0+cu128. Prebuilt voxelizers for GeForce RTX 20/30/40/50. Acceleration needs
RTX 30 series or newer (SM80+); older GPUs fall back to the original path automatically.

## Install

1. Extract the `ComfyUI-Direct3D-V3` folder into `ComfyUI/custom_nodes` (replace any previous Direct3D-V3 build).
2. Request access to DINOv3 ViT-H+ on Hugging Face (facebook/dinov3-vith16plus-pretrain-lvd1689m).
3. Run `setup.cmd` in the node folder. It creates `.runtime` with PyTorch, Triton and the dependencies, and
   downloads DINOv3 and the 1536 checkpoint. For cascade mode run `setup.cmd --models-only --stage all`.
4. Restart ComfyUI.

## accel_mode (all Refine nodes)

| mode | what it does |
| --- | --- |
| `lossless` (default) | Fused FP16 attention, decoder and RoPE kernels, async transfers. Same quality as FP16. |
| `fast` | + INT8 attention scores and SmoothQuant INT8 for the least sensitive layers (1536 stage). |
| `fastest` | + INT8 MLP layers. |
| `off` | Original path. |

## Multiview node

Connect the front image as usual and any of `back_image`, `left_image`, `right_image`, `top_image`, `bottom_image`,
each with an optional mask (white = object) and weight. Each view runs the model in an exactly turned patch frame;
the predictions are blended per patch at every step.

| Input | Camera | Image orientation |
| --- | --- | --- |
| back | behind the model | upright |
| left | at the model's left side (right edge of the front image) | upright |
| right | at the model's right side | upright |
| top | above | model's front at the image's bottom edge |
| bottom | below | model's front at the image's top edge |

* `multiview_mode`: `facing` (default) follows the view that sees each surface patch most head-on; `visible`,
  `blend`, `average` are alternatives.
* `multiview_speed`: `quality` (every view runs its own guided passes) or `fast` (views share the front's
  unconditional pass, about half the cost per extra view).
* Measured on an RTX 5050 Laptop 8 GB at 152,121 patches (`accel_mode=fast`): front only 459 s; front + back
  772 s with `multiview_speed=fast` or 983 s with `quality`; VRAM peak 7.6 GB.

Use view images with the same scale, framing and pose as the front image. Inconsistent views can hurt more than help.

Built on Direct3D-V3 (DreamTechAI), its geometry checkpoints (wushuang98/Direct3D-V3) and DINOv3. Licenses are
included; model weights are downloaded separately under their own terms.
