"""Install the Windows Direct3D-V3 worker in this node's private runtime."""

import argparse
import json
from pathlib import Path
import sysconfig
import subprocess
import sys
import venv

ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / ".runtime"
PYTHON = RUNTIME / "Scripts" / "python.exe"
CUDA = "12.8"
TORCH = "2.8.0"
VISION = "0.23.0"
INDEX = "https://download.pytorch.org/whl/cu128"
GEOMETRY = "wushuang98/Direct3D-V3"
GEOMETRY_REV = "78925d8647eb6f1b5ea75a27963bad6e1528f4f4"
DINO = "facebook/dinov3-vith16plus-pretrain-lvd1689m"
DINO_REV = "c807c9eeea853df70aec4069e6f56b28ddc82acc"


def run(*args, cwd=ROOT, env=None):
    command = [str(arg) for arg in args]
    print("\n>", subprocess.list2cmdline(command), flush=True)
    subprocess.run(command, cwd=cwd, env=env, check=True)


def install_runtime():
    if not PYTHON.is_file():
        venv.EnvBuilder(with_pip=True).create(RUNTIME)
    run(PYTHON, "-m", "pip", "install", "--only-binary=:all:", "--index-url", INDEX,
        f"torch=={TORCH}+cu128", f"torchvision=={VISION}+cu128")
    run(PYTHON, "-m", "pip", "install", "--only-binary=:all:", "-r", ROOT / "requirements-windows.txt")


def download_models(stage, birefnet):
    from huggingface_hub import hf_hub_download, login, snapshot_download
    from huggingface_hub.errors import GatedRepoError

    models = ROOT / "models" / "Direct3D-V3"
    encoder = models / "image_encoder"
    try:
        hf_hub_download(DINO, "config.json", revision=DINO_REV, local_dir=encoder)
    except GatedRepoError:
        print(f"Accept the DINOv3 license at https://huggingface.co/{DINO} and sign in with a read token.")
        login(add_to_git_credential=False)
    snapshot_download(DINO, revision=DINO_REV, local_dir=encoder,
                      allow_patterns=["config.json", "model.safetensors", "preprocessor_config.json"])
    stages = (512, 1024, 1536) if stage == "all" else (int(stage),)
    for number in stages:
        folder = f"shape_transformers_{number}"
        for filename in ("config.json", "model.safetensors"):
            hf_hub_download(GEOMETRY, f"{folder}/{filename}", revision=GEOMETRY_REV, local_dir=models)
    upstream_index = hf_hub_download(GEOMETRY, "model_index.json", revision=GEOMETRY_REV)
    index = json.loads(Path(upstream_index).read_text(encoding="utf-8"))
    index["image_encoder"] = "./image_encoder"
    (models / "model_index.json").write_text(json.dumps(index, indent=2) + "\n", encoding="utf-8")
    if birefnet:
        snapshot_download("ZhengPeng7/BiRefNet",
                          allow_patterns=["config.json", "model.safetensors", "*.py"])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=("512", "1024", "1536", "all"), default="1536",
                        help="checkpoint to download, or all for cascade workflows")
    parser.add_argument("--birefnet", action="store_true", help="also cache automatic background removal")
    parser.add_argument("--models-only", action="store_true", help="download weights using the existing worker runtime")
    parser.add_argument("--runtime-only", action="store_true", help="install dependencies and build extensions only")
    args = parser.parse_args()
    if args.models_only and args.runtime_only:
        parser.error("--models-only and --runtime-only are mutually exclusive")
    if sys.platform != "win32" or sys.version_info[:2] != (3, 12) or sysconfig.get_platform() != "win-amd64":
        parser.error("64-bit Python 3.12 on Windows is required")
    if args.models_only:
        if not PYTHON.is_file():
            parser.error("Run setup.cmd first to create .runtime")
        if Path(sys.executable).resolve() == PYTHON.resolve():
            download_models(args.stage, args.birefnet)
        else:
            flags = ["--birefnet"] if args.birefnet else []
            run(PYTHON, __file__, "--models-only", "--stage", args.stage, *flags)
        return
    install_runtime()
    if not args.runtime_only:
        flags = ["--birefnet"] if args.birefnet else []
        run(PYTHON, __file__, "--models-only", "--stage", args.stage, *flags)
    print("\nSetup complete. Restart ComfyUI.")


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError, subprocess.CalledProcessError) as error:
        sys.exit(f"Setup failed: {error}")
