"""Standalone Direct3D-V3 runner optimized for 8 GB NVIDIA GPUs.

Not imported by ComfyUI. Work is executed in a child Python 3.12 process so
ComfyUI's Python/Torch packages are untouched. No weights are bundled.
"""
import argparse
import gc
import json
import os
import sys
import threading
import time
import traceback
from contextlib import contextmanager
from pathlib import Path

ROOT = Path(__file__).resolve().parent
UPSTREAM = ROOT / "vendor" / "Direct3D-V3"


def emit(*args):
    print(*args, flush=True)


def _phase_logger(cuda, device):
    try:
        import psutil
    except ImportError:
        psutil = None
        emit("INFO psutil unavailable; RAM metrics disabled")
    process = psutil.Process() if psutil is not None else None
    mib = 1024**2

    @contextmanager
    def phase(name, stage=None):
        cuda.synchronize(device)
        cuda.reset_peak_memory_stats(device)
        allocated_start = cuda.memory_allocated(device)
        stop = threading.Event()
        ram = {}

        def snapshot():
            memory = process.memory_info()
            available = psutil.virtual_memory().available / mib
            ram["worker_rss_peak_mib"] = max(ram.get("worker_rss_peak_mib", 0), memory.rss / mib)
            private = getattr(memory, "private", None)
            if private is not None:
                ram["worker_private_peak_mib"] = max(ram.get("worker_private_peak_mib", 0), private / mib)
            ram["system_available_min_mib"] = min(ram.get("system_available_min_mib", available), available)

        def poll():
            while not stop.wait(0.1):
                snapshot()

        monitor = None
        if process is not None:
            snapshot()
            monitor = threading.Thread(target=poll, daemon=True)
            monitor.start()
        start = time.perf_counter()
        try:
            yield
            cuda.synchronize(device)
            elapsed = time.perf_counter() - start
        finally:
            stop.set()
            if monitor is not None:
                monitor.join()
        if process is not None:
            snapshot()
        metrics = dict(phase=name, stage=stage, seconds=round(elapsed, 4),
                       gpu_allocated_start_mib=allocated_start / mib,
                       gpu_allocated_end_mib=cuda.memory_allocated(device) / mib,
                       gpu_allocated_peak_mib=cuda.max_memory_allocated(device) / mib,
                       gpu_reserved_peak_mib=cuda.max_memory_reserved(device) / mib, **ram)
        emit("PROFILE", json.dumps(metrics, separators=(",", ":")))

    return phase


def _resolve_model_location(model, *, offline, resolution, stage_mode):
    """Prefer this node's manual model folder over the HF cache.

    Upstream accepts either a repository ID or a real folder.  When offline=True
    and the value stays at the default repository ID, Hugging Face can only look
    in its own cache, not in models/Direct3D-V3.  Resolve explicitly here.
    """
    value = str(model or "wushuang98/Direct3D-V3").strip().strip('"').strip()
    local_root = ROOT / "models" / "Direct3D-V3"
    if value == "wushuang98/Direct3D-V3" and (local_root / "model_index.json").is_file():
        value = str(local_root)
        emit(f"INFO Using locally installed Direct3D-V3 models: {value}")

    path = Path(value).expanduser()
    if path.is_dir():
        index_path = path / "model_index.json"
        if not index_path.is_file():
            raise FileNotFoundError(f"Missing local model index: {index_path}")
        index = json.loads(index_path.read_text(encoding="utf-8-sig"))
        stages = ([int(resolution)] if stage_mode == "single_stage" else
                  [r for r in (512, 1024, 1536) if r <= int(resolution)])
        missing = []
        for stage in stages:
            folder = index.get(f"shape_transformers_{stage}")
            if not isinstance(folder, str) or not folder:
                missing.append(f"model_index.json: shape_transformers_{stage} entry")
                continue
            for file in ("config.json", "model.safetensors"):
                target = path / folder / file
                if not target.is_file():
                    missing.append(str(target))

        encoder = index.get("image_encoder")
        if isinstance(encoder, str) and encoder.startswith("./"):
            for file in ("config.json", "model.safetensors"):
                target = path / encoder / file
                if not target.is_file():
                    missing.append(str(target))

        if missing:
            raise FileNotFoundError(
                "Local Direct3D-V3 checkpoint layout is incomplete.\n"
                + "\n".join("  Missing: " + x for x in missing)
                + "\nFor a 1536-only download, set resolution=1536 and stage_mode=single_stage."
            )
        emit(f"INFO Local stage checkpoints validated: {stages}")
        return str(path.resolve())

    # If a filesystem path is explicitly provided, do not confuse it with a
    # remote repository ID: fail early with a useful explanation.
    if path.is_absolute() or value.startswith((".", "~")):
        raise FileNotFoundError(f"Direct3D-V3 model folder does not exist: {path}")
    if offline and value == "wushuang98/Direct3D-V3":
        emit("WARNING: No models/Direct3D-V3/model_index.json found next to worker.py. "
             "Offline remote-ID mode searches ONLY the HF cache.")
    return value


def _run(config):
    options = {
        "DIRECT3D_V3_VOXEL_BACKEND": "sparse",
        "DIRECT3D_V3_TRIM_BLOCK": "1",
        "DIRECT3D_V3_HOST_SKIPS": "1",
        "DIRECT3D_V3_STAGE_QKV": "1",
        "DIRECT3D_V3_TILE_FINAL_NORM": "1",
        "DIRECT3D_V3_UNMASK_SINGLE_WINDOWS": "1",
    }
    for name, value in options.items():
        os.environ.setdefault(name, value)
    emit("INFO Clean worker options: " + ", ".join(f"{k}={os.environ[k]}" for k in options))
    if not (UPSTREAM / "direct3d" / "pipeline.py").is_file():
        raise RuntimeError("Direct3D-V3 source missing. Restore the bundled vendor folder.")
    sys.path.insert(0, str(UPSTREAM))
    from flash_sdpa_compat import attention_stats, install

    attention_backend = config.get("attention_backend", "efficient")
    if attention_backend not in ("efficient", "cudnn_fp16"):
        raise ValueError(f"Unknown attention backend: {attention_backend!r}")
    use_cudnn = attention_backend == "cudnn_fp16" and config.get("dtype") != "bf16"
    install(cudnn_fp16=use_cudnn)
    emit(f"INFO Attention backend requested: {attention_backend}; "
         f"effective mode: {'cudnn_fp16 (experimental)' if use_cudnn else 'efficient'}")

    import torch
    import trimesh
    from PIL import Image
    import cudavoxelize   # Bundled extension for this worker's CUDA build.

    from direct3d.pipeline import Direct3DV3Pipeline
    from direct3d.schedulers import sample_x0
    from direct3d.models.image_encoder import DINOv3FeatureExtractor
    from direct3d.utils.image import prepare_image
    from direct3d.utils.mesh import export_mesh
    from coarse_input import upload_coarse
    from direct3d.utils.voxelization import mesh_patches
    from direct3d.utils.sparse_mc import sparse_mc_infer
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable to the Direct3D worker. Check torch 2.8.0+cu128 and your NVIDIA driver.")
    if torch.__version__ != "2.8.0+cu128" or torch.version.cuda != "12.8":
        raise RuntimeError("This release expects torch 2.8.0+cu128. Run setup.cmd.")
    device = torch.device("cuda", torch.cuda.current_device())
    props = torch.cuda.get_device_properties(device)
    emit(f"INFO GPU={props.name}, VRAM={props.total_memory / 1024**3:.2f}GiB, torch={torch.__version__}, hole_fill=disabled")
    phase = _phase_logger(torch.cuda, device)
    emit(f"INFO CUDA allocator={torch.cuda.get_allocator_backend()}")

    dtype = torch.bfloat16 if config.get("dtype") == "bf16" else torch.float16
    model = _resolve_model_location(
        config.get("model"),
        offline=config.get("offline", False),
        resolution=config["resolution"],
        stage_mode=config.get("stage_mode", "cascade"),
    )
    pipe = Direct3DV3Pipeline(
        model,
        image_encoder=None,
        torch_dtype=dtype,
        revision=None,
        local_files_only=config.get("offline", False),
        stages=(),  # IMPORTANT: do not load all 3 stage checkpoints to CPU/RAM at once.
    )
    pipe.device = device  # Do NOT call .to(): that would move all stage models at once.
    try:
        conf = pipe._read_config("config.json")
    except FileNotFoundError:
        # Upstream supports old model_index.json-only local repos.
        conf = {}
    index = pipe._read_config(conf.get("model_index", "model_index.json"))

    with phase("prepare_image"):
        img_path = Path(config["image"])
        with Image.open(img_path) as im:
            image = im.copy()
        if config.get("use_alpha", False) and image.mode == "RGBA" and image.getextrema()[3] != (255, 255):
            foreground = image
            emit("INFO Using existing input alpha mask; skipping BiRefNet")
        else:
            emit("INFO Removing background with BiRefNet (first run downloads weights)")
            foreground = pipe.remove_background(image)
            pipe._remover = None
            torch.cuda.empty_cache()
        pixels = prepare_image(foreground)
        del image, foreground

    with phase("load_coarse_and_upload"):
        vertices, faces = upload_coarse(config["coarse_mesh"], device)
        emit(f"INFO Coarse input: {len(vertices)} vertices, {len(faces)} triangles")
    generator = torch.Generator(device=device).manual_seed(int(config["seed"]))
    stages = [r for r in (512, 1024, 1536) if r <= int(config["resolution"])]
    if config.get("stage_mode") == "single_stage":
        stages = [int(config["resolution"])]
    max_tokens = int(config["max_tokens"])
    steps = int(config["steps"])
    cfg = float(config["guidance"])
    emit(f"INFO Stages={stages}, max_tokens={max_tokens}, steps={steps}, CFG={cfg}")
    search_margin = 8.0 if os.environ.get("DIRECT3D_V3_LEGACY_VOXEL_MARGIN") == "1" else 0.0
    emit(f"INFO Voxel search margin={search_margin:.1f}")

    encoder = None
    reuse_gelu_override = os.environ.get("DIRECT3D_V3_REUSE_GELU")
    sort_qkv_override = os.environ.get("DIRECT3D_V3_SORT_QKV")
    tile_cross_override = os.environ.get("DIRECT3D_V3_TILE_CROSS_NORM")

    def trim():
        gc.collect()
        torch.cuda.empty_cache()

    with torch.inference_mode():
        for stage in stages:
            stage_key = f"shape_transformers_{stage}"
            if stage_key not in index:
                raise RuntimeError(f"Missing stage {stage} entry in model_index.json")
            folder = index[stage_key]
            stage_config = pipe._read_config(f"{folder}/config.json")
            if stage_config["resolution"] != stage:
                raise ValueError(f"Expected the {stage} stage config in {folder}.")
            patch_size = int(stage_config["denoiser"]["patch_size"])
            emit(f"STAGE {stage} voxelize coarse mesh")
            def report_patches(initial, accepted, retries, scale):
                emit(f"INFO Stage {stage} voxelization: initial_tokens={initial}, accepted_tokens={accepted}, "
                     f"shrink_iterations={retries}, effective_mesh_scale={scale:.12g}, "
                     f"longest_axis_grid_spacings={0.95 * (stage - 1) * scale:.3f}")

            with phase("voxelization", stage):
                coords = mesh_patches(vertices, faces, stage, patch_size, max_tokens,
                                      on_accepted=report_patches, search_margin=search_margin,
                                      allow_shrink=config.get("token_fit", "preserve_scale") == "shrink_to_fit")
                del vertices, faces
            trim()
            emit(f"INFO Stage {stage}: {len(coords)} sparse voxel patches")
            if encoder is None:
                emit("INFO Loading configured DINOv3 image encoder")
                with phase("load_encoder_cpu", stage):
                    encoder = DINOv3FeatureExtractor(
                        **pipe._encoder_options, dtype=dtype, local_files_only=config.get("offline", False)
                    )
            with phase("encoder_cpu_to_cuda", stage):
                encoder.to(device)
            try:
                with phase("encode_image", stage), torch.autocast("cuda", dtype=dtype):
                    context = encoder(pixels, int(stage_config["image_size"]))
            finally:
                if stage == stages[-1]:
                    with phase("release_encoder_and_trim", stage):
                        encoder = None
                        del pixels
                        trim()
                else:
                    with phase("encoder_cuda_to_cpu_and_trim", stage):
                        encoder.cpu()
                        trim()
            emit(f"STAGE {stage} load checkpoint")
            stream_checkpoint = False
            if sys.platform == "win32" and isinstance(pipe.repo, Path) and stage in (512, 1024, 1536):
                if os.environ.get("DIRECT3D_V3_LEGACY_DIT_LOAD") != "1":
                    from inspect import signature
                    from safetensors import safe_open
                    stream_checkpoint = "backend" in signature(safe_open).parameters
            if stream_checkpoint:
                from direct3d.models.checkpoint import load_denoiser
                high_token_run = len(coords) > 80000 and props.total_memory <= 9 * 1024**3
                stream_blocks = os.environ.get("DIRECT3D_V3_STREAM_BLOCKS", "1" if high_token_run else "0") == "1"
                reuse_gelu = reuse_gelu_override if reuse_gelu_override is not None else ("1" if stream_blocks else "0")
                sort_qkv = sort_qkv_override if sort_qkv_override is not None else ("1" if stream_blocks else "0")
                tile_cross = tile_cross_override if tile_cross_override is not None else (
                    "1" if stream_blocks and len(coords) > 120000 else "0"
                )
                os.environ["DIRECT3D_V3_REUSE_GELU"] = reuse_gelu
                os.environ["DIRECT3D_V3_SORT_QKV"] = sort_qkv
                os.environ["DIRECT3D_V3_TILE_CROSS_NORM"] = tile_cross
                emit(f"INFO Denoiser memory mode: block_streaming={stream_blocks}, "
                     f"reuse_gelu={reuse_gelu}, sort_qkv={sort_qkv}, tile_cross_norm={tile_cross}")
                with phase("load_denoiser_stream_to_cuda", stage):
                    denoiser = load_denoiser(pipe._model_file(f"{folder}/model.safetensors"),
                                             stage_config["denoiser"], dtype, device=device,
                                             stream_blocks=stream_blocks)
                    if stream_blocks:
                        weights = denoiser.streamed_blocks
                        emit(f"INFO Block weight streaming: {weights.host_bytes / 2**20:.1f} MiB CPU, "
                             f"{weights.staging.numel() * weights.staging.element_size() / 2**20:.1f} MiB GPU staging")
                        del weights
                    trim()
            else:
                with phase("load_denoiser_cpu", stage):
                    stage_config, denoiser = pipe._load_stage(stage, folder, None)
                with phase("denoiser_cpu_to_cuda_and_trim", stage):
                    denoiser.to(device)
                    trim()
            sampling = stage_config["sampling"].copy()
            sampling["steps"] = steps
            sampling["guidance_scale"] = cfg
            if (sys.platform == "win32" and torch.__version__ == "2.8.0+cu128"
                    and torch.cuda.get_device_capability(device) == (12, 0)
                    and dtype == torch.float16 and isinstance(pipe.repo, Path) and stages == [1536]
                    and os.environ.get("DIRECT3D_V3_LEGACY_UNCOND_CROSS") != "1"
                    and denoiser.cam_decoder is None and denoiser.depth == 17
                    and all(block.attn2.to_v.bias is None and block.attn2.out_proj.bias is not None
                            for block in denoiser.blocks)):
                sampling["project_unconditional_bias"] = True

            def cb(stage_id, completed, total):
                emit(f"PROGRESS {stage_id} {completed} {total}")

            emit(f"STAGE {stage} sampling")
            try:
                with phase("sample", stage), torch.autocast("cuda", dtype=dtype):
                    sdf = sample_x0(
                        denoiser,
                        coords.int(),
                        context,
                        generator,
                        patch_size=patch_size,
                        resolution=stage,
                        on_sampling_step=cb,
                        **sampling,
                    )
            finally:
                if use_cudnn:
                    counts = attention_stats()
                    emit(f"INFO Stage {stage} cuDNN attention: {counts['cudnn']} dispatched, "
                         f"{counts['fallback']} eligible calls fell back, "
                         f"{counts['baseline']} other calls kept the original path")
                with phase("release_denoiser_and_trim", stage):
                    del denoiser, context
                    trim()
            emit(f"STAGE {stage} marching cubes")
            with phase("marching_cubes_and_trim", stage):
                vertices, faces = sparse_mc_infer(
                    sdf.float(), coords[:, 1:], stage, patch_size,
                    mc_threshold=float(stage_config["mc_threshold"]), fill_holes=False,
                )
                del sdf, coords
                trim()
            emit(f"INFO Stage {stage} output: {len(vertices)} vertices, {len(faces)} triangles")

        emit("INFO Exporting raw marching-cubes triangles without decimation")
        with phase("mesh_to_cpu", stages[-1]):
            out_mesh = export_mesh(vertices, faces, None)
            del vertices, faces
        path = Path(config["output"])
        with phase("serialize_mesh", stages[-1]):
            path.parent.mkdir(parents=True, exist_ok=True)
            if path.suffix.lower() == ".glb":
                out_mesh.export(str(path), include_normals=False)
            else:
                out_mesh.export(str(path))
        emit(f"RESULT {path}")
        emit(f"INFO Completed: {len(out_mesh.vertices)} vertices, {len(out_mesh.faces)} triangles")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    try:
        with open(args.config, "r", encoding="utf-8") as handle:
            _run(json.load(handle))
    except Exception:
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
